package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;


import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.SerieResponse;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;

public class SerieViewModel extends AndroidViewModel {
    public static final String TAG = SerieViewModel.class.getSimpleName();


    private DamRepository damRepository;
    private MediatorLiveData<SerieResponse> serieResponse;

    @Inject
    public SerieViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository) {
        super(application);

        this.damRepository = damRepository;
        serieResponse = new MediatorLiveData<>();
    }


    public LiveData<SerieResponse> getSerie (String token, String idDam, String numSecSerie){
        if(serieResponse.getValue() == null){
            serieResponse.addSource(damRepository.getSerie(token, idDam, numSecSerie), serResponse -> serieResponse.setValue(serResponse));
        }
        return serieResponse;
    }
}
