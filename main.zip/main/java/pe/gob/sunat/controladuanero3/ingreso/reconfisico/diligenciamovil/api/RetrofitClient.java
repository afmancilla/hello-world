package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

public class RetrofitClient {
    private static Retrofit retrofit = null;

    public static  OkHttpClient.Builder getokhttpclient(Context context) throws CertificateException,IOException,
            KeyStoreException,NoSuchAlgorithmException,KeyManagementException {

        CertificateFactory cf= null;
        cf = CertificateFactory.getInstance("X.509");

        Certificate ca;
        try(InputStream cert = context.getResources().openRawResource(R.raw.certificadodesarrollo)){
            ca=cf.generateCertificate(cert);
        }

        String KeyStoreType = KeyStore.getDefaultType();
        KeyStore keyStore = KeyStore.getInstance(KeyStoreType);
        keyStore.load(null,null);
        keyStore.setCertificateEntry("ca",ca);
        String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);


        TrustManager[] trustManagers = tmf.getTrustManagers();
        X509TrustManager x509TrustManager = (X509TrustManager) trustManagers[0];

        SSLContext sslContext = SSLContext.getInstance("SSL");
        sslContext.init(null,tmf.getTrustManagers(),null);

        // Create an ssl socket factory with our all-trusting manager
        final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();


        OkHttpClient.Builder builder = new OkHttpClient.Builder().sslSocketFactory(sslSocketFactory,x509TrustManager );
        builder.hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        });

        return builder;


    }


    public static Retrofit getClient(String baseUrl, Context context) {


        try {

            if (retrofit == null) {
                retrofit = new Retrofit.Builder()
                        .baseUrl(baseUrl)
                        .client(getokhttpclient(context).build())
                        .addConverterFactory(JacksonConverterFactory.create())
                        .build();
            }



        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }



        return retrofit;
    }
}
