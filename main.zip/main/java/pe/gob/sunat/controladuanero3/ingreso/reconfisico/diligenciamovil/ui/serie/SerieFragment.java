package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie;

import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.adapter.AdapterSeriesList;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.SeriesViewModel;

import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.SUB_TITULO;


public class SerieFragment extends BaseFragment implements Injectable {

    public static final String TAG = SerieFragment.class.getSimpleName();

    Unbinder unbinder;

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_view_series)
    RecyclerView recyclerView;

    @BindView(R.id.text_view_subtitulo)
    TextView subTitulo;

    private View view;
    private AdapterSeriesList mAdapter;
    private SearchView searchView;
    private OnFragmentIterationListener listener;
    private SeriesViewModel viewModel;


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    public interface OnFragmentIterationListener {
        void setSerieDetalleFragment(Bundle bundle);
    }

    public SerieFragment() {
    }

    public static SerieFragment newInstance(Bundle params) {
        SerieFragment sf = new SerieFragment();
        sf.setArguments(params);
        return sf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {


        view = inflater.inflate(R.layout.fragment_series_list, container, false);
        unbinder = ButterKnife.bind(this, view);

        Bundle params = getArguments();
        subTitulo.setText(params.getString(Constantes.SUB_TITULO));

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterSeriesList(this.getContext(), new Series(), ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new AdapterSeriesList.OnItemClickListener() {
            @Override
            public void onItemClick(View view, Serie serie, int position) {

                if (listener != null) {
                    Bundle params = getArguments();
                    if (params != null) {
                        params.putString(Constantes.ARG_IDSERIE, serie.getNumSecSerie());
                    }
                    listener.setSerieDetalleFragment(params);
                }
            }
        });
        return view;
    }


    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(SeriesViewModel.class);

        Bundle params = getArguments();
        String token = params.getString(ARG_TOKEN);
        String idDam = params.getString(ARG_IDDAM);

        viewModel.getListaSeries(token, idDam).observe(this, serieslistResponse -> {
            if (serieslistResponse.getSeries() != null) {
                mAdapter.addItems(serieslistResponse.getSeries());
                ((BaseActivity)getActivity()).hideMessage();
            }

            if (serieslistResponse.getErrorGeneral() != null) {
                String codError = serieslistResponse.getErrorGeneral().getCod();
                String codMsg = serieslistResponse.getErrorGeneral().getMsg();
                Toast.makeText(getActivity(), codError + '-' + codMsg, Toast.LENGTH_SHORT).show();

                ((BaseActivity)getActivity()).hideMessage();

                if ("401".equals(codError)) {

                } else if ("404".equals(codError)) {
                    ((BaseActivity)getActivity()).showNoFound();
                } else {

                }
            }

            if (serieslistResponse.getError() != null) {
                ((MainActivity)getActivity()).hideMessage();
                Throwable e = serieslistResponse.getError();
                Toast.makeText(getActivity(), "Error is " + e.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Error is " + e.getLocalizedMessage());
            }
        });

    }


    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    //adicionado para el filter de series anita
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_serie, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_buscar).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")) {//bypass al hint
                    query = searchView.getQueryHint() + query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if (!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")) {//bypass al hint
                    query = searchView.getQueryHint() + query;
                }
                mAdapter.getFilter().filter(query);

                return false;
            }
        });
    }

    public void settleFilterOption(MenuItem item, String hint) {
        item.setChecked(true);
        this.searchView.setQueryHint(hint + ":");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

            /***FILTROS***/
            case R.id.submenu_f_nro_serie:
                settleFilterOption(item, "NRO SERIE");
                break;
            case R.id.submenu_f_nro_partida:
                settleFilterOption(item, "PARTIDA");
                break;
            case R.id.submenu_f_descr_merca:
                settleFilterOption(item, "DESCRIPCION");
                break;
            case R.id.submenu_f_fob:
                settleFilterOption(item, "FOB");
                break;
            case R.id.submenu_f_cod_liberatorio:
                settleFilterOption(item, "COD.LIBERATORIO");
                break;
            case R.id.submenu_f_tpi:
                settleFilterOption(item, "TPI");
                break;
            case R.id.submenu_f_tpn:
                settleFilterOption(item, "TPN");
                break;
            case R.id.submenu_f_pais_origen:
                settleFilterOption(item, "PAIS ORIGEN");
                break;
            case R.id.submenu_f_estado_merca:
                settleFilterOption(item, "ESTADO MERCANCIA");
                break;

            /***ORDENAMIENTOS***/
            case R.id.submenu_o_nro_serie:
                mAdapter.sorted("SERIE");
                break;
            case R.id.submenu_o_partida:
                mAdapter.sorted("PARTIDA");
                break;
            case R.id.submenu_o_descr_merca:
                mAdapter.sorted("DESCRIPCION");
            case R.id.submenu_o_fob:
                mAdapter.sorted("FOB");
                break;

        }

        return true;
    }

    //adicionado anita
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }


    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
