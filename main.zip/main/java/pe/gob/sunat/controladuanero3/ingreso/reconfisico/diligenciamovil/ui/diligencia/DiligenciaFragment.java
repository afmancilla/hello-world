package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia;


import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;

import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

public class DiligenciaFragment extends BaseFragment implements Injectable {

    public static final String TAG = DiligenciaFragment.class.getSimpleName();

    /*
    @BindView(R.id.linear_layout_preliminar)
    LinearLayout preliminar;*/

    Unbinder unbinder;

    @BindView(R.id.edit_text_detalle_diligencia)
    EditText detalleDiligencia;
    @BindView(R.id.edit_text_bultos_reconocidos)
    EditText bultosReconocidos;
    @BindView(R.id.edit_text_fecha_reconocimiento)
    EditText fechaReconocimiento;
    @BindView(R.id.grabar)
    FloatingActionButton grabar;
    @BindView(R.id.text_view_subtitulo)
    TextView subTitulo;

    private View view;
    private OnFragmentIterationListener listener;

    public interface OnFragmentIterationListener {
        void grabarDiligencia(Bundle bundle);
    }


    public DiligenciaFragment() {
    }

    public static DiligenciaFragment newInstance(Bundle params) {
        DiligenciaFragment df = new DiligenciaFragment();
        df.setArguments(params);
        return df;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_diligencia, container, false);
        unbinder = ButterKnife.bind(this, view);
        Bundle params = getArguments();
        subTitulo.setText(params.getString(Constantes.SUB_TITULO));

        fechaReconocimiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogDatePickerLight();
            }
        });

        grabar.setOnClickListener(view -> {

            if (listener != null && validarPantalla()) {

                try {
                    Date initDate = new SimpleDateFormat("dd/MM/yyyy").parse(fechaReconocimiento.getText().toString());

                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                    String parsedDate = formatter.format(initDate);

                    params.putString(Constantes.ARG_FEC_RECONFISICO,parsedDate);
                    params.putString(Constantes.ARG_DES_RESULTADO,detalleDiligencia.getText().toString());
                    params.putString(Constantes.ARG_CNT_BULTOSRECON,bultosReconocidos.getText().toString());
                    listener.grabarDiligencia(params);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        });

        /* no implementado fase2
        preliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.setDiligenciaPrevisionalFragment(null);
                }
            }
        });*/

        return view;
    }

    private boolean validarPantalla()  {
        boolean todoOk = false;

        if(detalleDiligencia.getText().length() > 5
                && bultosReconocidos.getText().length() > 0
                && fechaReconocimiento.getText().length() > 0 ) {

            try {
                Date initDate = new SimpleDateFormat("dd/MM/yyyy").parse(fechaReconocimiento.getText().toString());
                todoOk = true;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return todoOk;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
    }

    /*
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_diligencia, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_grabar:
                // ((MainActivity)getActivity()).replaceFragment(new BandejaFragment());
                createToastMessage("Diligencia Grabada.");
                break;
        }

        return super.onOptionsItemSelected(item);
    }*/

    private void createToastMessage(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }


    private void dialogDatePickerLight() {
        Calendar cur_calender = Calendar.getInstance();

        DatePickerDialog datePicker = DatePickerDialog.newInstance(
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, monthOfYear);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        long date = calendar.getTimeInMillis();

                        fechaReconocimiento.setText(Tools.getFormattedDateSimple(date));
                    }
                },
                cur_calender.get(Calendar.YEAR),
                cur_calender.get(Calendar.MONTH),
                cur_calender.get(Calendar.DAY_OF_MONTH)
        );
        datePicker.setThemeDark(false);
        datePicker.setAccentColor(getResources().getColor(R.color.colorPrimary));
        datePicker.setMinDate(cur_calender);
        datePicker.show(getActivity().getFragmentManager(),"Fecha Recon.Fisico");
    }



}
