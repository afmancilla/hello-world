package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;

public class SeriesResponse extends BaseResponse {

    private Series series;

    public SeriesResponse(Series series){
        this.error = null;
        this.errorGeneral = null;
        this.series = series;
    }

    public SeriesResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.series = null;
    }

    public SeriesResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.series = null;
    }

    /*** SET AND GET ***/

    public Series getSeries() {
        return series;
    }

    public void setSeries(Series series) {
        this.series = series;
    }
}

