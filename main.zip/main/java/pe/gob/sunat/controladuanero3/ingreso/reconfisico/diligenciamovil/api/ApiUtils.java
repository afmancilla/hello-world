package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api;

import android.content.Context;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.AsignacionApi;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DamApi;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DiligenciaApi;

public class ApiUtils {

    private ApiUtils() {
    }


    //public static final String BASE_URL = "https://api.sunat.gob.pe/"; // EMULADOR

    public static final String BASE_URL = "https://api.sunat.gob.pe:446/"; //CELULAR DESARROLLO
    //public static final String BASE_URL = "https://api.sunat.gob.pe:444/"; //CELULAR CALIDAD

    public static final String CLIENT_ID     = "90e2f3d4-33f6-41c2-984d-d7a6a7aa441e";
    public static final String CLIENT_SECRET = "6fRXdmapKuhMXxkdpR54bg";


    public static DamApi getDamApi(Context context) {

        return RetrofitClient.getClient(BASE_URL,context).create(DamApi.class);
    }

    public static AsignacionApi getAsignacionApi(Context context) {

        return RetrofitClient.getClient(BASE_URL,context).create(AsignacionApi.class);
    }



    public static DiligenciaApi getDiligenciaApi(Context context) {

        return RetrofitClient.getClient(BASE_URL,context).create(DiligenciaApi.class);
    }
}
