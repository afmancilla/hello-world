package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.ApiUtils;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Declaracion;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DeudaTributaria;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Items;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.LiquidacionCobranza;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Riesgo;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.AdvertenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DeclaracionResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DeudaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.ItemResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.ItemsResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.LiquidacionesResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.RiesgoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.SerieResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.SeriesResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DamApi;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@Singleton
public class DamRepository {

    private final static String TAG = DamRepository.class.getSimpleName();
    private DamApi damApi;

    @Inject
    public DamRepository(DamApi damApi) {
        this.damApi = damApi;
    }

    public LiveData<DeclaracionResponse> getDam(String token, String idDam){
        final MutableLiveData<DeclaracionResponse> damResponse = new MutableLiveData<>();

        damApi.buscarDamPorIdDam("Bearer " + token, idDam).enqueue(new Callback<Declaracion>() {
            @Override
            public void onResponse(Call<Declaracion> call, Response<Declaracion> response) {

                if (response.isSuccessful()) {
                    damResponse.postValue(new DeclaracionResponse(response.body()));
                   // Toast.makeText(application, "NUMCORREDOC: "+ response.body().getNumCorredoc(), Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());
                    damResponse.postValue(new DeclaracionResponse(errorGeneral));
                }
            }
            @Override
            public void onFailure(Call<Declaracion> call, Throwable t) {
                //Toast.makeText(application, "Fallo DeclaracionViewModel", Toast.LENGTH_LONG).show();
                damResponse.postValue(new DeclaracionResponse(t));
                Log.e(TAG, "onFailure:" + t.getMessage());
                t.printStackTrace();
            }
        });

        return damResponse;
    }

    public LiveData<AdvertenciaResponse> getAdvertencias(String token, String idDam){
        final MutableLiveData<AdvertenciaResponse> advertenciaResponse = new MutableLiveData<>();

        damApi.validarDAMParaDiligenciaMovil("Bearer " + token, idDam,"01").enqueue(new Callback<List<Advertencia>>() {
            @Override
            public void onResponse(Call<List<Advertencia>> call, Response<List<Advertencia>> response) {

                if (response.isSuccessful()) {
                    advertenciaResponse.postValue(new AdvertenciaResponse(response.body()));
                    //Toast.makeText(application, "Ok lista advertencias ", Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());
                    advertenciaResponse.postValue(new AdvertenciaResponse(errorGeneral));
                }
            }
            @Override
            public void onFailure(Call<List<Advertencia>> call, Throwable t) {
               // Toast.makeText(application, "Fallo DeclaracionViewModel", Toast.LENGTH_LONG).show();
                advertenciaResponse.postValue(new AdvertenciaResponse(t));
                Log.e(TAG, "onFailure:" + t.getMessage());
                t.printStackTrace();
            }
        });

        return advertenciaResponse;
    }



    public LiveData<SeriesResponse> getListSeries(String token, String idDam){
        final MutableLiveData<SeriesResponse> serieResponse = new MutableLiveData<>();

        damApi.buscarSeriesPorIdDam("Bearer "+token, idDam).enqueue(new Callback<Series>() {
            @Override
            public void onResponse(Call<Series> call, Response<Series> response) {

                if(response.isSuccessful()){

                    serieResponse.postValue(new SeriesResponse(response.body()));
                   // Toast.makeText(application, "Exito " + idDam, Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());

                    serieResponse.postValue(new SeriesResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<Series> call, Throwable t) {

                //Toast.makeText(application, "Fallo SeriesViewModel", Toast.LENGTH_SHORT).show();
                serieResponse.postValue(new SeriesResponse(t));
                Log.e(TAG,"onFailure: "+t.getMessage());
                t.printStackTrace();
            }
        });
        return serieResponse;
    }

    public LiveData<SerieResponse> getSerie(String token, String idDam, String numSecSerie){
        final MutableLiveData<SerieResponse> serieResponse = new MutableLiveData<>();

        damApi.buscarSeriesPorID("Bearer "+token, idDam,numSecSerie).enqueue(new Callback<Serie>() {
            @Override
            public void onResponse(Call<Serie> call, Response<Serie> response) {

                if(response.isSuccessful()){

                    serieResponse.postValue(new SerieResponse(response.body()));
                   // Toast.makeText(application, "Exito NumSecSerie" + numSecSerie, Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());

                    serieResponse.postValue(new SerieResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<Serie> call, Throwable t) {

               // Toast.makeText(application, "Fallo SerieViewModel", Toast.LENGTH_SHORT).show();
                serieResponse.postValue(new SerieResponse(t));
                Log.e(TAG,"onFailure: "+t.getMessage());
                t.printStackTrace();
            }
        });
        return serieResponse;
    }


    public LiveData<ItemsResponse> getListItems(String token, String idDam, String numSecSerie){
        final MutableLiveData<ItemsResponse> itemsResponse = new MutableLiveData<>();

        damApi.buscarItemsPorSerie("Bearer "+token, idDam,numSecSerie).enqueue(new Callback<Items>() {
            @Override
            public void onResponse(Call<Items> call, Response<Items> response) {

                if(response.isSuccessful()){

                    itemsResponse.postValue(new ItemsResponse(response.body()));
                 //   Toast.makeText(application, "Exito Serie" + numSecSerie, Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());

                    itemsResponse.postValue(new ItemsResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<Items> call, Throwable t) {

               // Toast.makeText(application, "Fallo SeriesViewModel", Toast.LENGTH_SHORT).show();
                itemsResponse.postValue(new ItemsResponse(t));
                Log.e(TAG,"onFailure: "+t.getMessage());
                t.printStackTrace();
            }
        });
        return itemsResponse;
    }

    public LiveData<ItemResponse> getItem(String token, String idDam, String numSecSerie, String numSecItem){
        final MutableLiveData<ItemResponse> itemResponse = new MutableLiveData<>();

        damApi.buscarItemsPorID("Bearer "+token, idDam,numSecSerie,numSecItem).enqueue(new Callback<Item>() {
            @Override
            public void onResponse(Call<Item> call, Response<Item> response) {

                if(response.isSuccessful()){

                    itemResponse.postValue(new ItemResponse(response.body()));
               //     Toast.makeText(application, "Exito NumSecSerie" + numSecSerie, Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());

                    itemResponse.postValue(new ItemResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<Item> call, Throwable t) {

               // Toast.makeText(application, "Fallo SerieViewModel", Toast.LENGTH_SHORT).show();
                itemResponse.postValue(new ItemResponse(t));
                Log.e(TAG,"onFailure: "+t.getMessage());
                t.printStackTrace();
            }
        });
        return itemResponse;
    }


    public LiveData<DeudaResponse> getDeudaTributaria(String token, String idDam){
        final MutableLiveData<DeudaResponse> deudaResponse = new MutableLiveData<>();

        damApi.buscarDeudasTributariasAduanerasPorIdDam("Bearer " + token, idDam,"01").enqueue(new Callback<DeudaTributaria>() {
            @Override
            public void onResponse(Call<DeudaTributaria> call, Response<DeudaTributaria> response) {

                if (response.isSuccessful()) {
                    deudaResponse.postValue(new DeudaResponse(response.body(),idDam));

                //    Toast.makeText(application, "NUMCORREDOC: "+ response.body(), Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());
                    deudaResponse.postValue(new DeudaResponse(errorGeneral));
                }
            }
            @Override
            public void onFailure(Call<DeudaTributaria> call, Throwable t) {
               // Toast.makeText(application, "Fallo DeclaracionViewModel", Toast.LENGTH_LONG).show();
                deudaResponse.postValue(new DeudaResponse(t));
                Log.e(TAG, "onFailure:" + t.getMessage());
                t.printStackTrace();
            }
        });

        return deudaResponse;
    }

    public LiveData<LiquidacionesResponse> getListaLCs(String token, String idDam){

        final MutableLiveData<LiquidacionesResponse> lcsResponse = new MutableLiveData<>();

        damApi.buscarLCPorIdDam("Bearer " + token, idDam).enqueue(new Callback<List<LiquidacionCobranza>>() {
            @Override
            public void onResponse(Call<List<LiquidacionCobranza>> call, Response<List<LiquidacionCobranza>> response) {
                if (response.isSuccessful()) {
                    lcsResponse.postValue(new LiquidacionesResponse(response.body()));
                //    Toast.makeText(application, "LC ok", Toast.LENGTH_LONG).show();
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());
                    lcsResponse.postValue(new LiquidacionesResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<List<LiquidacionCobranza>> call, Throwable t) {
               // Toast.makeText(application, "Fallo Riesgo", Toast.LENGTH_LONG).show();
                lcsResponse.postValue(new LiquidacionesResponse(t));
                Log.e(TAG, "onFailure:" + t.getMessage());
                t.printStackTrace();
            }
        });


        return lcsResponse;
    }
    //ParaRiesgo
    public LiveData<RiesgoResponse> getRiesgos(String token, String idDam){
        final MutableLiveData<RiesgoResponse> riesgoResponse = new MutableLiveData<>();

        damApi.buscarIndicadoresRiesgoPorIdDam("Bearer " + token, idDam).enqueue(new Callback<List<Riesgo>>(){
            @Override
            public void onResponse(Call<List<Riesgo>> call, Response<List<Riesgo>> response) {
                if (response.isSuccessful()) {
                    riesgoResponse.postValue(new RiesgoResponse(response.body(),idDam));
                   // Toast.makeText(application, "Ok lista riesgos ", Toast.LENGTH_LONG).show();
                }
                else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(""+response.code());
                    errorGeneral.setMsg(response.message());
                    riesgoResponse.postValue(new RiesgoResponse(errorGeneral));
                }
            }
            @Override
            public void onFailure(Call<List<Riesgo>> call, Throwable t) {
                //Toast.makeText(application, "Fallo Riesgo", Toast.LENGTH_LONG).show();
                riesgoResponse.postValue(new RiesgoResponse(t));
                Log.e(TAG, "onFailure:" + t.getMessage());
                t.printStackTrace();
            }
        });
        return riesgoResponse;
    }

}



