package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main;

import android.app.Dialog;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import okhttp3.Response;
import okhttp3.ResponseBody;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.BuildConfig;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.BandejaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.common.NavigationController;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.ContenedoresListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DeclaracionFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DocTransporteListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.DeudaTributariaActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia.DiligenciaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo.RiesgoActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Session;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.MainViewModel;
import timber.log.Timber;

public class MainActivity extends BaseActivity
        implements
        HasSupportFragmentInjector,
        BandejaFragment.OnFragmentIterationListener,
        DiligenciaFragment.OnFragmentIterationListener,
        DeclaracionFragment.OnFragmentIterationListener,
        SerieFragment.OnFragmentIterationListener,
        SerieDetalleFragment.OnFragmentIterationListener,
        ItemFragment.OnFragmentIterationListener,
        ItemDetalleFragment.OnFragmentIterationListener {

    public static final String TAG = MainActivity.class.getSimpleName();

    @Inject
    DispatchingAndroidInjector<Fragment> dispatchingAndroidInjector;

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    //@Inject
    //Session session;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.bottom_navigation_view_dam)
    BottomNavigationView bottomNavigationViewDam;

    @BindView(R.id.nav_view)
    NavigationView navView;

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;
    /*
    @BindView(R.id.loading)
    LinearLayout loading;
    @BindView(R.id.nofound)
    LinearLayout noFound;*/

    private ActionBar actionBar;
    private TextView nombreCompleto;
    private TextView email;

    private MainViewModel viewModel;

    @Inject
    NavigationController navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        AndroidInjection.inject(this);
        //ButterKnife.bind(this);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(MainViewModel.class);

        if (!session.isLoggedIn()) {
            showTokenDialog();
        }

        initToolbarHome();
        setInitialFragment();
        cargarDatosUsuario();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    /*
    public void showLoading() {
        hideMessage();
        loading.setVisibility(View.VISIBLE);
    }


    public void hideLoading() {
        loading.setVisibility(View.GONE);
    }

    public void showNoFound() {
        hideMessage();
        noFound.setVisibility(View.VISIBLE);
    }

    public void hideMessage() {
        noFound.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
    }*/


    private void setInitialFragment() {

        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(false);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(false);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(false);

        Bundle bundle = new Bundle();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_BANDEJA));
        }

        showLoading();


        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, BandejaFragment.newInstance(bundle), BandejaFragment.TAG);

        ft.commit();

        bottomNavigationViewDam.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.navigation_bandeja:
                        setBandejaFragment(bundle);
                        break;
                    case R.id.navigation_dam:
                        setDeclaracionFragment(bundle);
                        break;
                    case R.id.navigation_series:
                        setSeriesFragment(bundle);
                        break;
                    case R.id.navigation_diligencia:
                        setDiligenciaFragment(bundle);
                        break;
                }
                return true;
            }
        });

    }


    private void initToolbarHome() {

        toolbar.setNavigationIcon(R.drawable.ic_menu);
        setSupportActionBar(toolbar);

        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        Tools.setSystemBarColor(this);

        initNavigationMenu();
    }

    private void initToolbarBack() {

        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }


    private void initNavigationMenu() {


        MenuItem navItemDeuda = navView.getMenu().findItem(R.id.nav_deuda);
        MenuItem navItemRiezgo = navView.getMenu().findItem(R.id.nav_riesgo);
        navItemDeuda.setEnabled(false);
        navItemRiezgo.setEnabled(false);

        nombreCompleto = (TextView) navView.getHeaderView(0).findViewById(R.id.text_view_fullname);
        email = (TextView) navView.getHeaderView(0).findViewById(R.id.text_view_email);

        String codFuncionario = session.getCodFuncionario();
        viewModel.getFoto(session.getToken(), codFuncionario).observe(this, response -> {

            ResponseBody body = response.getResponseBody();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if (body != null) {
                downloadFoto(body,codFuncionario);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else if(Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                    showInfoMessage("No se encontro foto");
                }else {
                    Timber.e(throwable.getMessage());
                    showErrorMessage(throwable.getMessage());
                }
            }else if (throwable != null) {
                showErrorMessage(throwable.getMessage());
            }

        });



        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        drawerLayout.setDrawerListener(toggle);
        toggle.syncState();
        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(final MenuItem item) {
                Toast.makeText(getApplicationContext(), item.getTitle() + " Seleccionado", Toast.LENGTH_SHORT).show();
                actionBar.setTitle(item.getTitle());
                drawerLayout.closeDrawers();
                displayView(item.getItemId());
                return true;
            }


        });

    }

    private void downloadFoto(ResponseBody body, String codFuncionario) {

        Bitmap bitmap = Tools.getFoto(body,codFuncionario,this);
        ImageView image_view_foto = navView.getHeaderView(0).findViewById(R.id.image_view_foto);

        if (bitmap != null) {
            image_view_foto.setImageBitmap(Bitmap.createScaledBitmap(bitmap, 90, 100, true));
        }
    }

    private void displayView(int viewId) {
        switch (viewId) {

            case R.id.nav_riesgo:
                Intent intentRiesgo = new Intent(getApplicationContext(), RiesgoActivity.class);
                startActivity(intentRiesgo);
                break;
            case R.id.nav_deuda:
                Intent intentDeuda = new Intent(getApplicationContext(), DeudaTributariaActivity.class);

                startActivity(intentDeuda);
                break;
            case R.id.nav_salir:
                //dialogLogout();
                showLogoutDialog();
                break;
        }


    }

    /*
    private void dialogLogout() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // Setting Alert Dialog Title
        alertDialogBuilder.setTitle(R.string.app_name);
        // Icon Of Alert Dialog
        alertDialogBuilder.setIcon(R.drawable.ic_info);
        // Setting Alert Dialog Message
        alertDialogBuilder.setMessage("¿Estas seguro que quieres cerrar sesión?");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("Si", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                navigation.navifateToLogin();
                finish();
            }
        });
        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }*/

    /*
    private void salir() {
        session.logout();
        Intent intentStart = new Intent(getApplicationContext(), SplashActivity.class);
        intentStart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intentStart);
        finish();

    }*/

    private void cargarDatosUsuario() {
        nombreCompleto.setText(session.getNombreCompleto());
        email.setText(session.getCorreo());
    }


    public void setBandejaFragment(Bundle bundle) {

        initToolbarHome();

        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(false);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(false);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(false);


        MenuItem navItemDeuda = navView.getMenu().findItem(R.id.nav_deuda);
        MenuItem navItemRiezgo = navView.getMenu().findItem(R.id.nav_riesgo);
        navItemDeuda.setEnabled(false);
        navItemRiezgo.setEnabled(false);

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_BANDEJA));
        }

        showLoading();

        navigation.navigateToBandejaFragment(bundle);

        /*
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, BandejaFragment.newInstance(bundle), BandejaFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();*/
    }

    public void setDiligenciaFragment(Bundle bundle) {

        initToolbarHome();

        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);



        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_DILIGENCIA));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }
        //showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, DiligenciaFragment.newInstance(bundle), DiligenciaFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();
    }

    public void setSeriesFragment(Bundle bundle) {

        initToolbarHome();
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_SERIES));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }
        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, SerieFragment.newInstance(bundle), SerieFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void setDeclaracionFragment(Bundle bundle) {

        initToolbarHome();

        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);
        bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setChecked(true);

        MenuItem navItemDeuda = navView.getMenu().findItem(R.id.nav_deuda);
        MenuItem navItemRiezgo = navView.getMenu().findItem(R.id.nav_riesgo);
        navItemDeuda.setEnabled(true);
        navItemRiezgo.setEnabled(false);

        if (session.isLoggedIn()) {

            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            if (bundle != null && bundle.getString(Constantes.ARG_IDDAM) != null) {
                session.setIdDAM(bundle.getString(Constantes.ARG_IDDAM));
            }
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }
        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, DeclaracionFragment.newInstance(bundle), DeclaracionFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    public void grabarDiligencia(Bundle bundle) {

        showLoading();

        Diligencia diligencia = new Diligencia();
        diligencia.setCntBultosRecon(bundle.getString(Constantes.ARG_CNT_BULTOSRECON));
        diligencia.setCodFuncionario(session.getCodFuncionario());
        diligencia.setDesResultado(bundle.getString(Constantes.ARG_DES_RESULTADO));
        diligencia.setFecDiligencia(bundle.getString(Constantes.ARG_FEC_RECONFISICO));


        viewModel.postDiligencia(session.getToken(), diligencia, session.getIdDAM()).observe(this, response -> {

            Diligencia ok = response.getDiligencia();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if (ok != null) {
                hideMessage();
                showSuccesDialog();
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else if(Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                }else if (Constantes.ERROR_VALIDACION.equals(error.getCod())){
                    Timber.i(errorMsg);
                }else {
                    Timber.e(throwable.getMessage());
                    showErrorMessage(throwable.getMessage());
                }
            }else if (throwable != null) {
                showErrorMessage(throwable.getMessage());
            }
        });

    }

    /*private void mostrarConfirmacionGrabado() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_exito);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }*/

    @Override
    public void setDocTransporteListFragment(Bundle bundle) {

        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_DOCUTRANS));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, DocTransporteListFragment.newInstance(bundle), DocTransporteListFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDeclaracionFragment(bundle);
            }
        });
    }

    @Override
    public void setContenedoresListFragment(Bundle bundle) {

        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_CONTENEDORES));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, ContenedoresListFragment.newInstance(bundle), ContenedoresListFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDeclaracionFragment(bundle);

            }
        });
    }

    @Override
    public void setSerieDetalleFragment(Bundle bundle) {

        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            if (bundle != null && bundle.getString(Constantes.ARG_IDSERIE) != null) {
                session.setIdSERIE(bundle.getString(Constantes.ARG_IDSERIE));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_SERIE));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, SerieDetalleFragment.newInstance(bundle), SerieDetalleFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSeriesFragment(bundle);

            }
        });
    }

    @Override
    public void setItemsFragment(Bundle bundle) {

        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            if (bundle != null && bundle.getString(Constantes.ARG_IDSERIE) != null) {
                session.setIdSERIE(bundle.getString(Constantes.ARG_IDSERIE));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_ITEMS));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, ItemFragment.newInstance(bundle), ItemFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSerieDetalleFragment(bundle);

            }
        });
    }

    @Override
    public void setItemDetalleFragment(Bundle bundle) {
        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.ARG_IDSERIE, session.getIdSERIE());
            if (bundle != null && bundle.getString(Constantes.ARG_IDITEM) != null) {
                session.setIdITEM(bundle.getString(Constantes.ARG_IDITEM));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_ITEM));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, ItemDetalleFragment.newInstance(bundle), ItemDetalleFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setItemsFragment(bundle);

            }
        });
    }

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return dispatchingAndroidInjector;
    }


}
