package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.common;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;

import javax.inject.Inject;
import javax.inject.Singleton;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.BandejaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.SplashActivity;


public class NavigationController {

    private final int containerId;
    private final FragmentManager fragmentManager;
    private final Context context;

    @Inject
    public NavigationController(MainActivity mainActivity) {
        this.containerId = R.id.main_fragment_placeholder;
        this.fragmentManager = mainActivity.getSupportFragmentManager();
        this.context = mainActivity.getApplicationContext();
    }

    public void navigateToBandejaFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, BandejaFragment.newInstance(bundle),BandejaFragment.TAG)
                .addToBackStack(null)
                .commit();
    }


    public void navifateToLogin(){
        Intent intent = new Intent(context, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);

    }

}
