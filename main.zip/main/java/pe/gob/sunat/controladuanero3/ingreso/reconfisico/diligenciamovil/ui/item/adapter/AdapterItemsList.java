package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;

import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Items;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;


public class AdapterItemsList extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {
    private Context ctx;
    private Items items;
    private OnItemClickListener mOnItemClickListener;
    private int animation_type = 0;

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                String hint = !charString.isEmpty() && charString.contains(":")?
                        charString.substring(0,charString.indexOf(":")):"";

                if(!hint.isEmpty()) {
                    charString = charString.substring(charString.indexOf(":") + 1);
                }

                if (charString.isEmpty()) {
                    items.setItemsFiltrados(items.getItems());
                }else{
                    List<Item> lstItemsPorQuery = new ArrayList<>();

                    for(Item item: items.getItems()){

                        if(hint.equals("DESCRIPCION")) hint="";
                        String valorComparacion = obtenerValorComparador(hint, item);

                        if (valorComparacion.contains(charString.toLowerCase())) {
                            lstItemsPorQuery.add(item);
                        }
                    }
                    if(hint.isEmpty() && lstItemsPorQuery.size()==0){
                        items.setItemsFiltrados(items.getItems());
                    }else {
                    items.setItemsFiltrados(lstItemsPorQuery);
                }
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = items.getItemsFiltrados();
                return filterResults;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                items.setItemsFiltrados((List<Item>) filterResults.values);
                notifyDataSetChanged();
            }
        };
    }


    public String obtenerValorComparador(String hint, Item item){
        String valorComparacion = "";
        if(hint.equals("PARTIDA")){
            valorComparacion = item.getNumParArancel().toLowerCase();
        }else if(hint.equals("NRO ITEM")){
            valorComparacion = item.getNumSecItem().toLowerCase();
        }else if(hint.equals("FOB")){
            valorComparacion = item.getMtoFobItem().toString();
        }else if(hint.equals("PROVEEDOR")){
            valorComparacion = item.getFactura().getProveedor().getNumDocIdent()
            .concat(item.getFactura().getProveedor().getNomRazonSocial().toLowerCase());
        }else if(hint.equals("NRO FACTURA")){
            valorComparacion =item.getFactura().getNumFactura().toLowerCase();
        }else if(hint.equals("FECHA FACTURA")){
            valorComparacion = item.getFactura().getFecFact();
        }else{//default descomer, desmarca, desmodelo
            valorComparacion = (item.getDesComer().concat(" - ").concat(item.getDesMarca())
                    .concat(" - ").concat(item.getDesModelo()) ).toLowerCase();
        }
        return valorComparacion;
    }


    public void sorted(String tipoOrdenamiento) {
        if(tipoOrdenamiento.equals("ITEM")) {
            Collections.sort(this.items.getItems(), (o1, o2) -> o1.getNumSecItem().compareTo(o2.getNumSecItem()));
            this.items.setItemsFiltrados(this.items.getItems());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("PARTIDA")) {
            Collections.sort(this.items.getItems(), (o1, o2) -> o1.getNumParArancel().compareTo(o2.getNumParArancel()));
            this.items.setItemsFiltrados(this.items.getItems());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("DESCRIPCION")) {
            Collections.sort(this.items.getItems(), (o1, o2) -> o1.getDesComer().compareTo(o2.getDesComer()));
            this.items.setItemsFiltrados(this.items.getItems());//ordenadas
            notifyDataSetChanged();
        }else{
            Collections.sort(this.items.getItems(), (o1, o2) -> o1.getNumSecItem().compareTo(o2.getNumSecItem()));
            this.items.setItemsFiltrados(this.items.getItems());//ordenadas
            notifyDataSetChanged();
        }
    }

    public interface OnItemClickListener {
        void onItemClick(View view, Item item, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public AdapterItemsList(Context ctx, Items items, int animation_type) {
        this.items = items;
        this.items.setItemsFiltrados(items.getItems());
        this.ctx = ctx;
        this.animation_type = animation_type;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_items_list,parent,false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof OriginalViewHolder) {
               final OriginalViewHolder view = (OriginalViewHolder) holder;
               //final Item item = items.getItems().get(position);
                final Item item = items.getItemsFiltrados().get(position);
               view.numSecItem.setText(item.getNumSecItem());
                view.descripcion.setText(item.getDesComer());
                view.partida.setText(item.getNumParArancel());

                view.lyt_parent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mOnItemClickListener != null) {
                            mOnItemClickListener.onItemClick(view, item, position);
                        }
                    }
                });

                view.bt_expand.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean show = toggleLayoutExpand(!item.isExpanded(),v,view.lyt_expand);
                        //items.getItems().get(position).setExpanded(show);
                        items.getItemsFiltrados().get(position).setExpanded(show);
                    }
                });

            if(item.isExpanded()){
                view.lyt_expand.setVisibility(View.VISIBLE);
            } else {
                view.lyt_expand.setVisibility(View.GONE);
            }
            Tools.toggleArrow(item.isExpanded(), view.bt_expand, false);

            setAnimation(holder.itemView, position);
        }
    }

    private boolean toggleLayoutExpand(boolean show, View view, View lyt_expand) {
        Tools.toggleArrow(show, view);
        if (show) {
            ViewAnimation.expand(lyt_expand);
        } else {
            ViewAnimation.collapse(lyt_expand);
        }
        return show;
    }

    public void addItems(Items items){
        this.items = items;
        this.items.setItemsFiltrados(items.getItems());
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        //return  items.getItems()!=null?items.getItems().size():0;
        return items.getItemsFiltrados()!=null?
            items.getItemsFiltrados().size():0;

    }

    private class OriginalViewHolder extends RecyclerView.ViewHolder {


        public TextView numSecItem,partida,descripcion;
        public ImageButton bt_expand;
        public View lyt_expand;
        public View lyt_parent;

        public OriginalViewHolder(View v) {
            super(v);
            numSecItem = (TextView) v.findViewById(R.id.text_view_num_item);
            descripcion = (TextView) v.findViewById(R.id.text_view_descripcion);
            partida = v.findViewById(R.id.text_view_partida);
            bt_expand = (ImageButton) v.findViewById(R.id.bt_expand_items);
            lyt_expand = (View) v.findViewById(R.id.lyt_expand_items);
            lyt_parent = (View) v.findViewById(R.id.lyt_parent_items);
        }
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}
