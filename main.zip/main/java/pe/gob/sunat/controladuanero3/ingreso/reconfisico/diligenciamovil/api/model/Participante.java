package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Contiene los participantes que son declarados en los diferentes documentos aduaneros
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "rucRazonSocial",
        "numDocIdent",
        "nomRazonSocial"
})
public class Participante {


    @JsonProperty("rucRazonSocial")
    private String rucRazonSocial;

    @JsonProperty("numDocIdent")
    private String numDocIdent;

    @JsonProperty("nomRazonSocial")
    private String nomRazonSocial;

    public String getRucRazonSocial() {
        return rucRazonSocial;
    }

    public void setRucRazonSocial(String rucRazonSocial) {
        this.rucRazonSocial = rucRazonSocial;
    }

    public String getNumDocIdent() {
        return numDocIdent;
    }

    public void setNumDocIdent(String numDocIdent) {
        this.numDocIdent = numDocIdent;
    }

    public String getNomRazonSocial() {
        return nomRazonSocial;
    }

    public void setNomRazonSocial(String nomRazonSocial) {
        this.nomRazonSocial = nomRazonSocial;
    }
}



