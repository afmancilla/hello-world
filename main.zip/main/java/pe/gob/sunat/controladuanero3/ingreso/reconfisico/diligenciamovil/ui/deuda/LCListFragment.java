package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.adapter.AdapterLCList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.LiquidacionesViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;

import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;


public class LCListFragment extends BaseFragment implements Injectable {

    public static final String TAG = LCListFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_view_lcs)
    RecyclerView recyclerView;

    @BindView(R.id.text_view_subtitulo)
    TextView subTitulo;

    Unbinder unbinder;
    private View view;
    private AdapterLCList mAdapter;
    private LiquidacionesViewModel viewModel;

    public LCListFragment() {
    }

    public static LCListFragment newInstance(Bundle params) {
        LCListFragment lcf = new LCListFragment();
        lcf.setArguments(params);
        return lcf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_lcs_list, container, false);
        unbinder = ButterKnife.bind(this, view);

        Bundle params = getArguments();
        subTitulo.setText(params.getString(Constantes.SUB_TITULO));

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterLCList(this.getContext(), new ArrayList<>(),ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(LiquidacionesViewModel.class);

        String token = getArguments()!=null?getArguments().getString(ARG_TOKEN):"";
        String idDam = getArguments()!=null?getArguments().getString(ARG_IDDAM):"";

        viewModel.getListaLCs(token,idDam).observe(this,response -> {
            if(response.getLcs()!=null){
                ((DeudaTributariaActivity)getActivity()).hideMessage();

                mAdapter.addItems(response.getLcs());
            }
            if(response.getErrorGeneral()!=null){
                String codError = response.getErrorGeneral().getCod();
                String codMsg   = response.getErrorGeneral().getMsg();
                Toast.makeText(getActivity(), codError+'-'+codMsg , Toast.LENGTH_SHORT).show();

                ((BaseActivity)getActivity()).hideMessage();

                if("401".equals(codError)){

                }else if("404".equals(codError)){
                    ((BaseActivity)getActivity()).showNoFound();
                }else {

                }

            }
            if(response.getError()!=null){
                ((BaseActivity)getActivity()).hideMessage();
                Throwable e = response.getError();
                Toast.makeText(getActivity(), "Error is "+e.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Error is "+e.getLocalizedMessage());
            }
        });
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
    }
}
