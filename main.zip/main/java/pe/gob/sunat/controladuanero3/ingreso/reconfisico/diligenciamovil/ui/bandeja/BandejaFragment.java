package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja;



import android.app.Dialog;
import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentoAsignado;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.adapter.AdapterDocumentosList;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.BandejaViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;



public class BandejaFragment extends Fragment implements Injectable {

    public static final String TAG = BandejaFragment.class.getSimpleName();


    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_bandeja)
    RecyclerView recyclerView;

   Unbinder unbinder;
    private View view;
    private AdapterDocumentosList mAdapter;
    private SearchView searchView;
    private OnFragmentIterationListener listener;
    private BandejaViewModel viewModel;
    private ViewPropertyAnimator animation;

    public BandejaFragment() {
    }

   @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    public interface OnFragmentIterationListener {
        void setDeclaracionFragment(Bundle bundle);
    }

    public static BandejaFragment newInstance(Bundle params) {
        BandejaFragment bf = new BandejaFragment();
        bf.setArguments(params);

        return bf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }



    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_bandeja, container, false);
        unbinder = ButterKnife.bind(this, view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterDocumentosList(this.getContext(), new DocumentosAsignados(),ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new AdapterDocumentosList.OnItemClickListener() {
            @Override
            public void onItemClick(View view, DocumentoAsignado documento, int position) {

                if (listener != null) {

                    Bundle bundle = getArguments();
                    String token = bundle.getString(Constantes.ARG_TOKEN);

                    viewModel.getListaAdvertencias(token,documento.getIdDam()).observe(getActivity(), advResponse -> {

                        List<Advertencia> advertencias = advResponse.getAdvertencias();
                        bundle.putString(Constantes.ARG_TITULO_DAM, "DAM " + documento.getIdDam());
                        if(advertencias!=null){

                            if(advertencias.size()==0){
                                bundle.putString(Constantes.ARG_IDDAM,documento.getIdDam());
                                listener.setDeclaracionFragment(bundle);
                            }else{
                                mostrarAdvertencias(advResponse.getAdvertencias(),documento);
                            }
                        }

                        if(advResponse.getErrorGeneral()!=null){
                            Toast.makeText(getActivity(), advResponse.getErrorGeneral().getCod()+'-'+advResponse.getErrorGeneral().getMsg(), Toast.LENGTH_SHORT).show();
                            if(advResponse.getErrorGeneral().getCod().equals("404")){

                                bundle.putString(Constantes.ARG_IDDAM,documento.getIdDam());

                                listener.setDeclaracionFragment(bundle);
                            }
                        }

                        if(advResponse.getError()!=null){
                            Throwable e = advResponse.getError();
                            Toast.makeText(getActivity(), "Error is " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "Error is " + e.getLocalizedMessage());
                        }
                    });
                }
            }
        });

        return view;
    }

    private void mostrarAdvertencias(List<Advertencia> lstAdvertencias,DocumentoAsignado documento){
        final Dialog dialog = new Dialog(view.getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_advertencias);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        ((TextView)(dialog.findViewById(R.id.idDam))).setText(documento.getIdDam());

        String textoAdvertencia = "";
        for (Advertencia advertencia : lstAdvertencias) {
            textoAdvertencia = textoAdvertencia.concat(advertencia.getDetalle() + "\n");
        }

        ((TextView)(dialog.findViewById(R.id.advertencias))).setText(textoAdvertencia);

        ((ImageButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        ((Button) dialog.findViewById(R.id.bt_Continuar)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Bundle bundle =  getArguments();
                bundle.putString(Constantes.ARG_IDDAM,documento.getIdDam());
                listener.setDeclaracionFragment(bundle);
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
/*
    private void showCustomDialog() {
        final Dialog dialog = new Dialog(view.getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_token);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), ((AppCompatButton) v).getText().toString() + " Clicked", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }*/

/*
    private void toastIconError() {
        Toast toast = new Toast(view.getContext());
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText("This is Error Message");
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_close);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.red_600));

        toast.setView(custom_view);
        toast.show();
    }

    private void toastIconSuccess() {
        Toast toast = new Toast(view.getContext());
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText("Success!");
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_done);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.green_500));

        toast.setView(custom_view);
        toast.show();
    }*/

    /*
    private void toastIconInfo() {
        Toast toast = new Toast(view.getContext());
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText("Some Info Text Here");
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_error_outline);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.blue_500));

        toast.setView(custom_view);
        toast.show();
    }*/
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(BandejaViewModel.class);


        String token = getArguments()!=null?getArguments().getString(Constantes.ARG_TOKEN):"";
        String codFuncionario = getArguments()!=null?getArguments().getString(Constantes.ARG_COD_FUNCIONARIO):"";


        viewModel.getListaDocumentosAsignados(token,codFuncionario).observe(this,docAsigResponse -> {

            if(docAsigResponse.getDocumentosAsignados()!=null){

                ((BaseActivity)getActivity()).hideMessage();
                mAdapter.addItems(docAsigResponse.getDocumentosAsignados());
            }

            if(docAsigResponse.getErrorGeneral()!=null){

                String codError = docAsigResponse.getErrorGeneral().getCod();
                String codMsg   = docAsigResponse.getErrorGeneral().getMsg();
                Toast.makeText(getActivity(), codError+'-'+codMsg , Toast.LENGTH_SHORT).show();

                if("401".equals(codError)){

                }else if("404".equals(codError)){
                    ((BaseActivity)getActivity()).showNoFound();
                }else {

                }
            }

            if(docAsigResponse.getError()!=null){
                ((BaseActivity)getActivity()).hideMessage();
                Throwable e = docAsigResponse.getError();
                Toast.makeText(getActivity(), "Error is " + e.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Error is " + e.getLocalizedMessage());
            }
        });

    }



    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_bandeja, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_buscar).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //mAdapter.getFilter().filter(query.concat(menu.findItem(R.id.menu_filtrar).toString()));
                if(!"".equals(searchView.getQueryHint()) &&  !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if(!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

            /**FILTROS**/
            case R.id.submenu_f_G160:
                mAdapter.getFilter().filter("G160:"+this.searchView.getQuery());
                break;
            case R.id.submenu_f_OEA:
                mAdapter.getFilter().filter("OEA:"+this.searchView.getQuery());
                break;
            /**ORDENAMIENTOS**/
            case R.id.submenu_o_fechaasig:
                mAdapter.sorted("FECHA_ASIG");
                break;
            case R.id.submenu_o_nro_dam:
                mAdapter.sorted("IDDAM");
                break;
            case R.id.submenu_o_cant_series:
                mAdapter.sorted("CANTSERIES");
                break;
        }

        return true;
    }

    private void createToastMessage(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
