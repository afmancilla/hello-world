package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.DeudaTributariaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.LCListFragment;

@Module
public abstract class FragmentBuildersDeudaModule {
    @ContributesAndroidInjector
    abstract LCListFragment contributeLCListFragment();

    @ContributesAndroidInjector
    abstract DeudaTributariaFragment contributeDeudaTributariaFragment();
}
