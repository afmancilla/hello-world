package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Session;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;

public class DeudaTributariaActivity extends BaseActivity
        implements
        HasSupportFragmentInjector,
        DeudaTributariaFragment.OnFragmentIterationListener {

    public static final String TAG = DeudaTributariaActivity.class.getSimpleName();

    @Inject
    DispatchingAndroidInjector<Fragment> dispatchingAndroidInjector;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    /*@BindView(R.id.loading)
    LinearLayout loading;
    @BindView(R.id.nofound)
    LinearLayout noFound;*/
    @BindView(R.id.main_fragment_placeholder)
    FrameLayout mainFragmentPlaceholder;

    //private Session session;

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return dispatchingAndroidInjector;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_deuda_tributaria);
        AndroidInjection.inject(this);
        //ButterKnife.bind(this);
        //session = new Session(this);

        initToolbarHome();
        setInitialFragment();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_deuda_tributaria;
    }

    /*
    public void showLoading() {
        hideMessage();
        loading.setVisibility(View.VISIBLE);
    }


    public void hideLoading() {
        loading.setVisibility(View.GONE);
    }

    public void showNoFound() {
        hideMessage();
        noFound.setVisibility(View.VISIBLE);
    }

    public void hideMessage() {
        noFound.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
    }*/

    private void setInitialFragment() {

        Bundle bundle = new Bundle();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_DEUDA));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }

        showLoading();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, DeudaTributariaFragment.newInstance(bundle), DeudaTributariaFragment.TAG);
        ft.commit();
    }


    private void initToolbarHome() {

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this);
    }

    private void initToolbarBack() {

        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
    }

    @Override
    public void setLCListFragment(Bundle bundle) {

        initToolbarBack();

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_LCS));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }
        showLoading();

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_fragment_placeholder, LCListFragment.newInstance(bundle), LCListFragment.TAG);
        ft.addToBackStack(null);
        ft.commit();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setInitialFragment();
            }
        });
    }
}