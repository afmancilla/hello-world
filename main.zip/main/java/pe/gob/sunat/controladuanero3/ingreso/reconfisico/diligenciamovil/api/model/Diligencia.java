
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Contiene los datos generales de las Diligencias
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tipoDiligencia",
        "indIncidencia",
        "indMulta",
        "indImagen",
        "indPaseARecFisico",
        "codMotivo",
        "desResultado",
        "cntBultosRecon",
        "codFuncionario",
        "fecDiligencia",
        "indGrabado"
})
public class Diligencia {

    @JsonProperty("tipoDiligencia")
    private Catalogo tipoDiligencia;

    @JsonProperty("indIncidencia")
    private String indIncidencia;

    @JsonProperty("indMulta")
    private String indMulta;

    @JsonProperty("indImagen")
    private String indImagen;

    @JsonProperty("indPaseARecFisico")
    private String indPaseARecFisico;

    @JsonProperty("codMotivo")
    private String codMotivo;

    @JsonProperty("desResultado")
    private String desResultado;

    @JsonProperty("cntBultosRecon")
    private String cntBultosRecon;

    @JsonProperty("codFuncionario")
    private String codFuncionario;

    @JsonProperty("fecDiligencia")
    private String fecDiligencia;

    @JsonProperty("indGrabado")
    private String indGrabado;

    /******************* GET AND SET ***********************/

    public Catalogo getTipoDiligencia() {
        return tipoDiligencia;
    }

    public void setTipoDiligencia(Catalogo tipoDiligencia) {
        this.tipoDiligencia = tipoDiligencia;
    }

    public String getIndIncidencia() {
        return indIncidencia;
    }

    public void setIndIncidencia(String indIncidencia) {
        this.indIncidencia = indIncidencia;
    }

    public String getIndMulta() {
        return indMulta;
    }

    public void setIndMulta(String indMulta) {
        this.indMulta = indMulta;
    }

    public String getIndImagen() {
        return indImagen;
    }

    public void setIndImagen(String indImagen) {
        this.indImagen = indImagen;
    }

    public String getIndPaseARecFisico() {
        return indPaseARecFisico;
    }

    public void setIndPaseARecFisico(String indPaseARecFisico) {
        this.indPaseARecFisico = indPaseARecFisico;
    }

    public String getCodMotivo() {
        return codMotivo;
    }

    public void setCodMotivo(String codMotivo) {
        this.codMotivo = codMotivo;
    }

    public String getDesResultado() {
        return desResultado;
    }

    public void setDesResultado(String desResultado) {
        this.desResultado = desResultado;
    }

    public String getCntBultosRecon() {
        return cntBultosRecon;
    }

    public void setCntBultosRecon(String cntBultosRecon) {
        this.cntBultosRecon = cntBultosRecon;
    }

    public String getCodFuncionario() {
        return codFuncionario;
    }

    public void setCodFuncionario(String codFuncionario) {
        this.codFuncionario = codFuncionario;
    }

    public String getFecDiligencia() {
        return fecDiligencia;
    }

    public void setFecDiligencia(String fecDiligencia) {
        this.fecDiligencia = fecDiligencia;
    }

    public String getIndGrabado() {
        return indGrabado;
    }

    public void setIndGrabado(String indGrabado) {
        this.indGrabado = indGrabado;
    }
}



