package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Items;
public class ItemsResponse extends BaseResponse{

    private Items items;

    public ItemsResponse(Items items){
        this.error = null;
        this.errorGeneral = null;
        this.items = items;
    }

    public ItemsResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.items = null;
    }

    public ItemsResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.items = null;
    }

    /*** SET AND GET ***/

    public Items getItems() {
        return items;
    }

    public void setItems(Items items) {
        this.items = items;
    }
}
