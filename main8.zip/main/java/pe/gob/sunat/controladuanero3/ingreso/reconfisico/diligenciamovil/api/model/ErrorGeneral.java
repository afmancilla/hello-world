
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;


/**
 * ErrorGeneral
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "cod",
        "msg",
        "exc"
})
public class ErrorGeneral {

    @JsonProperty("cod")
    private String cod;

    @JsonProperty("msg")
    private String msg;

    @JsonProperty("exc")
    private String exc;

    @JsonProperty("errors")
    private List<Error> errors;

    /*** SET AND GET ***/
    public String getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = ""+cod;
    }

    public void setCod(String cod) {
        this.cod = cod!=null?cod:"";
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg!=null?msg:"";
    }

    public String getExc() {
        return exc;
    }

    public void setExc(String exc) {
        this.exc = exc!=null?exc:"";
    }

    public List<Error> getErrors() {
        return errors;
    }

    public void setErrors(List<Error> errors) {
        this.errors = errors;
    }
}



