package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;



/**
 * Contiene los datos provenientes de la declaracion del valor
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numSecprove",
        "proveedor"
})
public class Proveedor {


    @JsonProperty("numSecprove")
    private String numSecprove;

    @JsonProperty("rucRazonSocial")
    private String rucRazonSocial;

    @JsonProperty("numDocIdent")
    private String numDocIdent;

    @JsonProperty("nomRazonSocial")
    private String nomRazonSocial;

    /******************* GET AND SET ***********************/

    public String getNumSecprove() {
        return numSecprove;
    }

    public void setNumSecprove(String numSecprove) {
        this.numSecprove = numSecprove;
    }

    public String getRucRazonSocial() {
        return rucRazonSocial;
    }

    public void setRucRazonSocial(String rucRazonSocial) {
        this.rucRazonSocial = rucRazonSocial;
    }

    public String getNumDocIdent() {
        return numDocIdent;
    }

    public void setNumDocIdent(String numDocIdent) {
        this.numDocIdent = numDocIdent;
    }

    public String getNomRazonSocial() {
        return nomRazonSocial;
    }

    public void setNomRazonSocial(String nomRazonSocial) {
        this.nomRazonSocial = nomRazonSocial;
    }
}



