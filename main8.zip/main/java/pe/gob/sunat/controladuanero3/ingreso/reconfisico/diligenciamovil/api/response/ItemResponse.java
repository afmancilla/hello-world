package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;

public class ItemResponse extends BaseResponse {

    private Item item;

    /*** CONSTRUCTORES ***/
    public ItemResponse(Item item){
        this.error = null;
        this.errorGeneral = null;
        this.item = item;
    }

    public ItemResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.item = null;
    }

    public ItemResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.item = null;
    }

    /******** SET AND GET*********/

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }
}
