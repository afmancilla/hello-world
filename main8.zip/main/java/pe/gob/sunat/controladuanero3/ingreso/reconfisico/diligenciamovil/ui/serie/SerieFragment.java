package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie;

import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;


import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.adapter.AdapterSeriesList;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.SeriesViewModel;
import timber.log.Timber;

import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;


public class SerieFragment extends BaseFragment implements Injectable {

    public static final String TAG = SerieFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_view_series)
    RecyclerView recyclerView;

    private View view;
    private AdapterSeriesList mAdapter;
    private SearchView searchView;
    private OnFragmentIterationListener listener;
    private SeriesViewModel viewModel;

    public interface OnFragmentIterationListener {
        void setSerieDetalleFragment(Bundle bundle);
    }

    public SerieFragment() {
    }

    public static SerieFragment newInstance(Bundle params) {
        SerieFragment sf = new SerieFragment();
        sf.setArguments(params);
        return sf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_series_list, container, false);
        return view;
    }


    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterSeriesList(this.getContext(), new Series(), ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener((View view, Serie serie, int position) -> {

            if (listener != null) {
                Bundle params1 = getArguments();
                if (params1 != null) {
                    params1.putString(Constantes.ARG_IDSERIE, serie.getNumSecSerie());
                }
                listener.setSerieDetalleFragment(params1);
            }
        });

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(SeriesViewModel.class);

        Bundle params = getArguments();
        String token = params.getString(ARG_TOKEN);
        String idDam = params.getString(ARG_IDDAM);
        setSubTitulo(params.getString(Constantes.SUB_TITULO));

        viewModel.getListaSeries(token, idDam).observe(this, response -> {

            ((BaseActivity) getActivity()).hideMessage();
            Series series = response.getSeries();
            ErrorGeneral error = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if (series != null) {
                mAdapter.addItems(series);
            } else if (error != null) {

                String errorMsg = error.getCod().concat(":").concat(error.getMsg() + "->").concat(error.getExc());

                if (Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())) {
                    Timber.w(errorMsg);
                    ((BaseActivity) getActivity()).showTokenDialog();
                } else if (Constantes.ERROR_NO_FOUND.equals(error.getCod())) {
                    Timber.i(errorMsg);
                    ((BaseActivity) getActivity()).showNoFound();
                } else {
                    Timber.e(errorMsg);
                    ((BaseActivity) getActivity()).showErrorMessage(errorMsg);
                }
            } else if (throwable != null) {
                Timber.e(throwable.getMessage());
                ((BaseActivity) getActivity()).showErrorMessage(throwable.getMessage());
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    //adicionado para el filter de series anita
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_serie, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_buscar).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")) {//bypass al hint
                    query = searchView.getQueryHint() + query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if (!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")) {//bypass al hint
                    query = searchView.getQueryHint() + query;
                }
                mAdapter.getFilter().filter(query);

                return false;
            }
        });
    }

    public void settleFilterOption(MenuItem item, String hint) {
        item.setChecked(true);
        this.searchView.setQueryHint(hint + ":");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

            /***FILTROS***/
            case R.id.submenu_f_nro_serie:
                settleFilterOption(item, "NRO SERIE");
                break;
            case R.id.submenu_f_nro_partida:
                settleFilterOption(item, "PARTIDA");
                break;
            case R.id.submenu_f_descr_merca:
                settleFilterOption(item, "DESCRIPCION");
                break;
            case R.id.submenu_f_fob:
                settleFilterOption(item, "FOB");
                break;
            case R.id.submenu_f_cod_liberatorio:
                settleFilterOption(item, "COD.LIBERATORIO");
                break;
            case R.id.submenu_f_tpi:
                settleFilterOption(item, "TPI");
                break;
            case R.id.submenu_f_tpn:
                settleFilterOption(item, "TPN");
                break;
            case R.id.submenu_f_pais_origen:
                settleFilterOption(item, "PAIS ORIGEN");
                break;
            case R.id.submenu_f_estado_merca:
                settleFilterOption(item, "ESTADO MERCANCIA");
                break;

            /***ORDENAMIENTOS***/
            case R.id.submenu_o_nro_serie:
                mAdapter.sorted("SERIE");
                break;
            case R.id.submenu_o_partida:
                mAdapter.sorted("PARTIDA");
                break;
            case R.id.submenu_o_descr_merca:
                mAdapter.sorted("DESCRIPCION");
            case R.id.submenu_o_fob:
                mAdapter.sorted("FOB");
                break;

        }

        return true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
