package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentoTransporte;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.adapter.AdapterDocuTransList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;


public class DocTransporteListFragment extends BaseFragment implements Injectable {

    public static final String TAG = DocTransporteListFragment.class.getSimpleName();

    @BindView(R.id.recycler_view_doctransportes)
    RecyclerView recyclerView;

    private View view;
    private AdapterDocuTransList mAdapter;

    public DocTransporteListFragment() {
    }

    public static DocTransporteListFragment newInstance(Bundle params) {
        DocTransporteListFragment fragment = new DocTransporteListFragment();
        fragment.setArguments(params);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_docutrans_list, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {
        recyclerView = getView().findViewById(R.id.recycler_view_doctransportes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));
        List<DocumentoTransporte> transportes = (ArrayList) params.getSerializable(Constantes.ARG_LIST_DOCTRANSPORTES);

        mAdapter = new AdapterDocuTransList(this.getContext(), transportes, ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        if (transportes.size() == 0) {
            ((BaseActivity)getActivity()).showNoFound();
        }
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
    }
}
