package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import android.widget.LinearLayout;
import android.widget.TextView;


import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.AndroidInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Riesgo;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo.adapter.AdapterRiesgosList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.RiesgoViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;

import timber.log.Timber;

public class RiesgoActivity extends BaseActivity {

    private static String TAG = RiesgoActivity.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.recycler_view_riesgos)
    RecyclerView recyclerView;

    @BindView(R.id.text_view_subtitulo)
    TextView subTitulo;

    private AdapterRiesgosList mAdapter;


    private RiesgoViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        initToolbarHome();
        initComponent();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_riesgo;
    }

    private void initToolbarHome() {

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tools.setSystemBarColor(this);
    }

    private void initComponent() {

        if (session.isLoggedIn()) {
            subTitulo.setText(session.getTitulo(Constantes.ARG_TITULO_RIESGO));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(RiesgoViewModel.class);
        viewModel.getRiesgos(session.getToken(), session.getIdDAM()).observe(this, response -> {

            hideMessage();
            List<Riesgo> riesgos = response.getRiesgos();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if(riesgos!=null){
                cargarPantallaRiesgos(riesgos);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else if (Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                    showNoFound();
                }else {
                    Timber.e(errorMsg);
                    showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                showErrorMessage(throwable.getMessage());
            }

        });
    }

    private void cargarPantallaRiesgos(List<Riesgo> riesgos) {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new LineItemDecoration(this, LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);
        mAdapter = new AdapterRiesgosList(this, riesgos);
        recyclerView.setAdapter(mAdapter);
    }
}