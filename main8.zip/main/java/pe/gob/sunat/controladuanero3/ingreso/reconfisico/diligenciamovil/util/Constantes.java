package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util;

import android.net.Uri;

public class Constantes {

    public static final Uri CONTENT_URI = Uri.parse("content://pe.gob.sunat.authenticatorClientesSunat.provider/UsersClientesSunat");

    //Nombre del paquete donde se encuentra el authenticator
    public static final String AUTHENTICATOR_PACKAGE="pe.gob.sunat.tecnologia.seguridad.AuthenticatorClientesSunat";

    //Parámetro que recibe el authenticator para redireccionar a la aplicacion principal
    public static final String KEY_APLICATION_PRINCIPAL="rutaApp";

    //Nombre parametro - client id
    public static final String KEY_CLIENT_ID="clientId";

    //Nombre parametro - client secret
    public static final String KEY_CLIENT_SECRET="clientSecret";

    //NOMBRE DEL PAQUETE ACTUAL
    public static final String APLICATION_PRINCIPAL="pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil";

    //Nombre del tipo de cuenta
    public static final String ACCOUNT_TYPE = "pe.gob.sunat.clientessunat.auth";

    //Parametro de acceso
    public static final String AUTHTOKEN_TYPE_FULL_ACCESS ="Full access";

    public static final String[] columnas = new String[] {"_id","usuario","token" };

    public static final String ARG_TOKEN = "token";
    public static final String ARG_IDDAM = "idDam";
    public static final String ARG_COD_FUNCIONARIO = "codFuncionario";
    public static final String ARG_LIST_DOCTRANSPORTES = "DOCUMENTOSTRANSPORTE";
    public static final String ARG_LIST_CONTENEDORES = "CONTENEDORES";

    //TITULOS DE LAS PANTALLAS
    public static final String ARG_TITULO_BANDEJA = "TITULO_BANDEJA";
    public static final String ARG_TITULO_DAM = "TITULO_DAM";
    public static final String ARG_TITULO_DOCUTRANS = "TITULO_DOCUTRANS";
    public static final String ARG_TITULO_CONTENEDORES = "TITULO_CONTENEDORES";
    public static final String ARG_TITULO_SERIES = "TITULO_SERIES";
    public static final String ARG_TITULO_SERIE = "TITULO_SERIE";
    public static final String ARG_TITULO_ITEMS = "TITULO_ITEMS";
    public static final String ARG_TITULO_ITEM = "TITULO_ITEM";

    public static final String ARG_TITULO_DILIGENCIA = "TITULO_DILIGENCIA";
    public static final String ARG_TITULO_RIESGO = "TITULO_RIESGO";
    public static final String ARG_TITULO_DEUDA = "TITULO_DEUDA";
    public static final String ARG_TITULO_LCS = "TITULO_LCS";

    public static final String ARG_IDSERIE = "numSecSerie";
    public static final String ARG_IDITEM = "numSecItem";
    public static final String SUB_TITULO = "SUB_TITULO";

    public static final String ARG_FEC_RECONFISICO = "FEC_RECONFISICO";
    public static final String ARG_DES_RESULTADO = "DES_RESULTADO";
    public static final String ARG_CNT_BULTOSRECON = "CNT_BULTOSRECON";

    public final static int LOADING_DURATION = 20000;

    public final static String ERROR_TOKEN_INVALIDO = "401";
    public final static String ERROR_NO_FOUND = "404";
    public final static String ERROR_VALIDACION = "422";

    //advertencias de backend:
    public static final String ARG_TIPO_ADVERTENCIA_BANDEJA = "01";
    public static final String ARG_TIPO_ADVERTENCIA_DILIGENCIA = "02";
}
