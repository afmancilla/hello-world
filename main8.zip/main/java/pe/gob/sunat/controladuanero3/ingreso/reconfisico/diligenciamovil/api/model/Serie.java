
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * Contiene los Datos de las series de las declaraciones aduaneras
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numSecSerie",
        "descripcion",
        "numPartNandi",
        "ultractividad",
        "codUniComer",
        "cntComer",
        "cntBulto",
        "codClaseBultos",
        "cntPesoNeto",
        "cntPesoBruto",
        "codUniFisica",
        "cntUniFis",
        "codUniIsc",
        "cntUniIsc",
        "numParnaladisa",
        "numParnabandina",
        "numParCorrelacion",
        "paisOrigen",
        "paisAdquisicion",
        "paisProcedencia",
        "moneTranssaccion",
        "mtoFobMonTrans",
        "mtoFobDol",
        "mtoFleteDol",
        "mtoSegDol",
        "mtoAjuste",
        "mtoOtrosAjustes",
        "mtoValorAdu",
        "codTipSeg",
        "codTipFlete",
        "desComer",
        "desFormaPresen",
        "desMateComp",
        "desUsoAplic",
        "desOtrosCarac",
        "codEstMerc",
        "fecExpiracion",
        "codTipTasaAplicar",
        "codTipMargen",
        "mtoEstimado",
        "codValorAjuste",
        "codPuerEmbar",
        "fecEmbarque",
        "tipoDocumentoTranspporte",
        "numDocTransp",
        "numDocTranspMaster",
        "fecEmbOrigen",
        "tipoExoneracionRestrigida",
        "exomeracionRestringida",
        "codProdRestr",
        "riesgoSenasa",
        "codExpoAplicAntid",
        "codProdAntid",
        "mtoFobFact",
        "cntPesoVehic",
        "numDetalle",
        "mtoTotValPag",
        "codUbigeo",
        "codTipoMercEsp",
        "desMercEsp",
        "numEmbParcial",
        "mtoFobUnitario",
        "convenios",
        "links"
})
public class Serie extends BaseModel{


    @JsonProperty("numSecSerie")
    private String numSecSerie;

    @JsonProperty("descripcion")
    private String descripcion;

    @JsonProperty("numPartNandi")
    private String numPartNandi;

    @JsonProperty("ultractividad")
    private Catalogo ultractividad;

    @JsonProperty("codUniComer")
    private Catalogo codUniComer;

    @JsonProperty("cntComer")
    private BigDecimal cntComer;

    @JsonProperty("cntBulto")
    private BigDecimal cntBulto;

    @JsonProperty("codClaseBultos")
    private String codClaseBultos;

    @JsonProperty("cntPesoNeto")
    private BigDecimal cntPesoNeto;

    @JsonProperty("cntPesoBruto")
    private BigDecimal cntPesoBruto;

    @JsonProperty("codUniFisica")
    private Catalogo codUniFisica;

    @JsonProperty("cntUniFis")
    private BigDecimal cntUniFis;

    @JsonProperty("codUniIsc")
    private String codUniIsc;

    @JsonProperty("cntUniIsc")
    private BigDecimal cntUniIsc;

    @JsonProperty("numParnaladisa")
    private String numParnaladisa;

    @JsonProperty("numParnabandina")
    private String numParnabandina;

    @JsonProperty("numParCorrelacion")
    private String numParCorrelacion;

    @JsonProperty("paisOrigen")
    private Catalogo paisOrigen;

    @JsonProperty("paisAdquisicion")
    private Catalogo paisAdquisicion;

    @JsonProperty("paisProcedencia")
    private Catalogo paisProcedencia;

    @JsonProperty("moneTranssaccion")
    private Catalogo moneTranssaccion;

    @JsonProperty("mtoFobMonTrans")
    private BigDecimal mtoFobMonTrans;

    @JsonProperty("mtoFobDol")
    private BigDecimal mtoFobDol;

    @JsonProperty("mtoFleteDol")
    private BigDecimal mtoFleteDol;

    @JsonProperty("mtoSegDol")
    private BigDecimal mtoSegDol;

    @JsonProperty("mtoAjuste")
    private BigDecimal mtoAjuste;

    @JsonProperty("mtoOtrosAjustes")
    private BigDecimal mtoOtrosAjustes;

    @JsonProperty("mtoValorAdu")
    private BigDecimal mtoValorAdu;

    @JsonProperty("codTipSeg")
    private String codTipSeg;

    @JsonProperty("codTipFlete")
    private String codTipFlete;

    @JsonProperty("desComer")
    private String desComer;

    @JsonProperty("desFormaPresen")
    private String desFormaPresen;

    @JsonProperty("desMateComp")
    private String desMateComp;

    @JsonProperty("desUsoAplic")
    private String desUsoAplic;

    @JsonProperty("desOtrosCarac")
    private String desOtrosCarac;

    @JsonProperty("codEstMerc")
    private Catalogo codEstMerc;

    @JsonProperty("fecExpiracion")
    private String fecExpiracion;

    @JsonProperty("codTipTasaAplicar")
    private String codTipTasaAplicar;

    @JsonProperty("codTipMargen")
    private String codTipMargen;

    @JsonProperty("mtoEstimado")
    private BigDecimal mtoEstimado;

    @JsonProperty("codValorAjuste")
    private String codValorAjuste;

    @JsonProperty("codPuerEmbar")
    private String codPuerEmbar;

    @JsonProperty("fecEmbarque")
    private Date fecEmbarque;

    @JsonProperty("tipoDocumentoTranspporte")
    private Catalogo tipoDocumentoTranspporte;

    @JsonProperty("numDocTransp")
    private String numDocTransp;

    @JsonProperty("numDocTranspMaster")
    private String numDocTranspMaster;

    @JsonProperty("fecEmbOrigen")
    private Date fecEmbOrigen;

    @JsonProperty("tipoExoneracionRestrigida")
    private Catalogo tipoExoneracionRestrigida;

    @JsonProperty("exoneracionRestringida")
    private String exoneracionRestringida;

    @JsonProperty("codProdRestr")
    private String codProdRestr;

    @JsonProperty("riesgoSenasa")
    private Catalogo riesgoSenasa;

    @JsonProperty("codExpoAplicAntid")
    private String codExpoAplicAntid;

    @JsonProperty("codProdAntid")
    private String codProdAntid;

    @JsonProperty("mtoFobFact")
    private BigDecimal mtoFobFact;

    @JsonProperty("cntPesoVehic")
    private BigDecimal cntPesoVehic;

    @JsonProperty("numDetalle")
    private String numDetalle;

    @JsonProperty("mtoTotValPag")
    private BigDecimal mtoTotValPag;

    @JsonProperty("codUbigeo")
    private String codUbigeo;

    @JsonProperty("codTipoMercEsp")
    private String codTipoMercEsp;

    @JsonProperty("desMercEsp")
    private String desMercEsp;

    @JsonProperty("numEmbParcial")
    private String numEmbParcial;

    @JsonProperty("mtoFobUnitario")
    private BigDecimal mtoFobUnitario;

    @JsonProperty("convenios")
    private List<Convenio> convenios;

    @JsonProperty("links")
    private List<Link> links;

    /******************* GET AND SET ***********************/

    public String getNumSecSerie() {
        return numSecSerie;
    }

    public void setNumSecSerie(String numSecSerie) {
        this.numSecSerie = numSecSerie;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNumPartNandi() {
        return numPartNandi;
    }

    public void setNumPartNandi(String numPartNandi) {
        this.numPartNandi = numPartNandi;
    }

    public Catalogo getUltractividad() {
        return ultractividad;
    }

    public void setUltractividad(Catalogo ultractividad) {
        this.ultractividad = ultractividad;
    }

    public Catalogo getCodUniComer() {
        return codUniComer;
    }

    public void setCodUniComer(Catalogo codUniComer) {
        this.codUniComer = codUniComer;
    }

    public BigDecimal getCntComer() {
        return cntComer;
    }

    public void setCntComer(BigDecimal cntComer) {
        this.cntComer = cntComer;
    }

    public BigDecimal getCntBulto() {
        return cntBulto;
    }

    public void setCntBulto(BigDecimal cntBulto) {
        this.cntBulto = cntBulto;
    }

    public String getCodClaseBultos() {
        return codClaseBultos;
    }

    public void setCodClaseBultos(String codClaseBultos) {
        this.codClaseBultos = codClaseBultos;
    }

    public BigDecimal getCntPesoNeto() {
        return cntPesoNeto;
    }

    public void setCntPesoNeto(BigDecimal cntPesoNeto) {
        this.cntPesoNeto = cntPesoNeto;
    }

    public BigDecimal getCntPesoBruto() {
        return cntPesoBruto;
    }

    public void setCntPesoBruto(BigDecimal cntPesoBruto) {
        this.cntPesoBruto = cntPesoBruto;
    }

    public Catalogo getCodUniFisica() {
        return codUniFisica;
    }

    public void setCodUniFisica(Catalogo codUniFisica) {
        this.codUniFisica = codUniFisica;
    }

    public BigDecimal getCntUniFis() {
        return cntUniFis;
    }

    public void setCntUniFis(BigDecimal cntUniFis) {
        this.cntUniFis = cntUniFis;
    }

    public String getCodUniIsc() {
        return codUniIsc;
    }

    public void setCodUniIsc(String codUniIsc) {
        this.codUniIsc = codUniIsc;
    }

    public BigDecimal getCntUniIsc() {
        return cntUniIsc;
    }

    public void setCntUniIsc(BigDecimal cntUniIsc) {
        this.cntUniIsc = cntUniIsc;
    }

    public String getNumParnaladisa() {
        return numParnaladisa;
    }

    public void setNumParnaladisa(String numParnaladisa) {
        this.numParnaladisa = numParnaladisa;
    }

    public String getNumParnabandina() {
        return numParnabandina;
    }

    public void setNumParnabandina(String numParnabandina) {
        this.numParnabandina = numParnabandina;
    }

    public String getNumParCorrelacion() {
        return numParCorrelacion;
    }

    public void setNumParCorrelacion(String numParCorrelacion) {
        this.numParCorrelacion = numParCorrelacion;
    }

    public Catalogo getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(Catalogo paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public Catalogo getPaisAdquisicion() {
        return paisAdquisicion;
    }

    public void setPaisAdquisicion(Catalogo paisAdquisicion) {
        this.paisAdquisicion = paisAdquisicion;
    }

    public Catalogo getPaisProcedencia() {
        return paisProcedencia;
    }

    public void setPaisProcedencia(Catalogo paisProcedencia) {
        this.paisProcedencia = paisProcedencia;
    }

    public Catalogo getMoneTranssaccion() {
        return moneTranssaccion;
    }

    public void setMoneTranssaccion(Catalogo moneTranssaccion) {
        this.moneTranssaccion = moneTranssaccion;
    }

    public BigDecimal getMtoFobMonTrans() {
        return mtoFobMonTrans;
    }

    public void setMtoFobMonTrans(BigDecimal mtoFobMonTrans) {
        this.mtoFobMonTrans = mtoFobMonTrans;
    }

    public BigDecimal getMtoFobDol() {
        return mtoFobDol;
    }

    public void setMtoFobDol(BigDecimal mtoFobDol) {
        this.mtoFobDol = mtoFobDol;
    }

    public BigDecimal getMtoFleteDol() {
        return mtoFleteDol;
    }

    public void setMtoFleteDol(BigDecimal mtoFleteDol) {
        this.mtoFleteDol = mtoFleteDol;
    }

    public BigDecimal getMtoSegDol() {
        return mtoSegDol;
    }

    public void setMtoSegDol(BigDecimal mtoSegDol) {
        this.mtoSegDol = mtoSegDol;
    }

    public BigDecimal getMtoAjuste() {
        return mtoAjuste;
    }

    public void setMtoAjuste(BigDecimal mtoAjuste) {
        this.mtoAjuste = mtoAjuste;
    }

    public BigDecimal getMtoOtrosAjustes() {
        return mtoOtrosAjustes;
    }

    public void setMtoOtrosAjustes(BigDecimal mtoOtrosAjustes) {
        this.mtoOtrosAjustes = mtoOtrosAjustes;
    }

    public BigDecimal getMtoValorAdu() {
        return mtoValorAdu;
    }

    public void setMtoValorAdu(BigDecimal mtoValorAdu) {
        this.mtoValorAdu = mtoValorAdu;
    }

    public String getCodTipSeg() {
        return codTipSeg;
    }

    public void setCodTipSeg(String codTipSeg) {
        this.codTipSeg = codTipSeg;
    }

    public String getCodTipFlete() {
        return codTipFlete;
    }

    public void setCodTipFlete(String codTipFlete) {
        this.codTipFlete = codTipFlete;
    }

    public String getDesComer() {
        return desComer;
    }

    public void setDesComer(String desComer) {
        this.desComer = desComer;
    }

    public String getDesFormaPresen() {
        return desFormaPresen;
    }

    public void setDesFormaPresen(String desFormaPresen) {
        this.desFormaPresen = desFormaPresen;
    }

    public String getDesMateComp() {
        return desMateComp;
    }

    public void setDesMateComp(String desMateComp) {
        this.desMateComp = desMateComp;
    }

    public String getDesUsoAplic() {
        return desUsoAplic;
    }

    public void setDesUsoAplic(String desUsoAplic) {
        this.desUsoAplic = desUsoAplic;
    }

    public String getDesOtrosCarac() {
        return desOtrosCarac;
    }

    public void setDesOtrosCarac(String desOtrosCarac) {
        this.desOtrosCarac = desOtrosCarac;
    }

    public Catalogo getCodEstMerc() {
        return codEstMerc;
    }

    public void setCodEstMerc(Catalogo codEstMerc) {
        this.codEstMerc = codEstMerc;
    }

    public String getFecExpiracion() {
        return fecExpiracion;
    }

    public void setFecExpiracion(String fecExpiracion) {
        this.fecExpiracion = fecExpiracion;
    }

    public String getCodTipTasaAplicar() {
        return codTipTasaAplicar;
    }

    public void setCodTipTasaAplicar(String codTipTasaAplicar) {
        this.codTipTasaAplicar = codTipTasaAplicar;
    }

    public String getCodTipMargen() {
        return codTipMargen;
    }

    public void setCodTipMargen(String codTipMargen) {
        this.codTipMargen = codTipMargen;
    }

    public BigDecimal getMtoEstimado() {
        return mtoEstimado;
    }

    public void setMtoEstimado(BigDecimal mtoEstimado) {
        this.mtoEstimado = mtoEstimado;
    }

    public String getCodValorAjuste() {
        return codValorAjuste;
    }

    public void setCodValorAjuste(String codValorAjuste) {
        this.codValorAjuste = codValorAjuste;
    }

    public String getCodPuerEmbar() {
        return codPuerEmbar;
    }

    public void setCodPuerEmbar(String codPuerEmbar) {
        this.codPuerEmbar = codPuerEmbar;
    }

    public Date getFecEmbarque() {
        return fecEmbarque;
    }

    public void setFecEmbarque(Date fecEmbarque) {
        this.fecEmbarque = fecEmbarque;
    }

    public Catalogo getTipoDocumentoTranspporte() {
        return tipoDocumentoTranspporte;
    }

    public void setTipoDocumentoTranspporte(Catalogo tipoDocumentoTranspporte) {
        this.tipoDocumentoTranspporte = tipoDocumentoTranspporte;
    }

    public String getNumDocTransp() {
        return numDocTransp;
    }

    public void setNumDocTransp(String numDocTransp) {
        this.numDocTransp = numDocTransp;
    }

    public String getNumDocTranspMaster() {
        return numDocTranspMaster;
    }

    public void setNumDocTranspMaster(String numDocTranspMaster) {
        this.numDocTranspMaster = numDocTranspMaster;
    }

    public Date getFecEmbOrigen() {
        return fecEmbOrigen;
    }

    public void setFecEmbOrigen(Date fecEmbOrigen) {
        this.fecEmbOrigen = fecEmbOrigen;
    }

    public Catalogo getTipoExoneracionRestrigida() {
        return tipoExoneracionRestrigida;
    }

    public void setTipoExoneracionRestrigida(Catalogo tipoExoneracionRestrigida) {
        this.tipoExoneracionRestrigida = tipoExoneracionRestrigida;
    }

    public String getExoneracionRestringida() {
        return exoneracionRestringida;
    }

    public void setExoneracionRestringida(String exoneracionRestringida) {
        this.exoneracionRestringida = exoneracionRestringida;
    }

    public String getCodProdRestr() {
        return codProdRestr;
    }

    public void setCodProdRestr(String codProdRestr) {
        this.codProdRestr = codProdRestr;
    }

    public Catalogo getRiesgoSenasa() {
        return riesgoSenasa;
    }

    public void setRiesgoSenasa(Catalogo riesgoSenasa) {
        this.riesgoSenasa = riesgoSenasa;
    }

    public String getCodExpoAplicAntid() {
        return codExpoAplicAntid;
    }

    public void setCodExpoAplicAntid(String codExpoAplicAntid) {
        this.codExpoAplicAntid = codExpoAplicAntid;
    }

    public String getCodProdAntid() {
        return codProdAntid;
    }

    public void setCodProdAntid(String codProdAntid) {
        this.codProdAntid = codProdAntid;
    }

    public BigDecimal getMtoFobFact() {
        return mtoFobFact;
    }

    public void setMtoFobFact(BigDecimal mtoFobFact) {
        this.mtoFobFact = mtoFobFact;
    }

    public BigDecimal getCntPesoVehic() {
        return cntPesoVehic;
    }

    public void setCntPesoVehic(BigDecimal cntPesoVehic) {
        this.cntPesoVehic = cntPesoVehic;
    }

    public String getNumDetalle() {
        return numDetalle;
    }

    public void setNumDetalle(String numDetalle) {
        this.numDetalle = numDetalle;
    }

    public BigDecimal getMtoTotValPag() {
        return mtoTotValPag;
    }

    public void setMtoTotValPag(BigDecimal mtoTotValPag) {
        this.mtoTotValPag = mtoTotValPag;
    }

    public String getCodUbigeo() {
        return codUbigeo;
    }

    public void setCodUbigeo(String codUbigeo) {
        this.codUbigeo = codUbigeo;
    }

    public String getCodTipoMercEsp() {
        return codTipoMercEsp;
    }

    public void setCodTipoMercEsp(String codTipoMercEsp) {
        this.codTipoMercEsp = codTipoMercEsp;
    }

    public String getDesMercEsp() {
        return desMercEsp;
    }

    public void setDesMercEsp(String desMercEsp) {
        this.desMercEsp = desMercEsp;
    }

    public String getNumEmbParcial() {
        return numEmbParcial;
    }

    public void setNumEmbParcial(String numEmbParcial) {
        this.numEmbParcial = numEmbParcial;
    }

    public BigDecimal getMtoFobUnitario() {
        return mtoFobUnitario;
    }

    public void setMtoFobUnitario(BigDecimal mtoFobUnitario) {
        this.mtoFobUnitario = mtoFobUnitario;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public List<Convenio> getConvenios() {
        return convenios;
    }

    public void setConvenios(List<Convenio> convenios) {
        this.convenios = convenios;
    }
}



