package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.LiquidacionCobranza;

public class LiquidacionesResponse extends BaseResponse {
    private List<LiquidacionCobranza> lcs;

    public LiquidacionesResponse(List<LiquidacionCobranza> lcs){
        this.error = null;
        this.errorGeneral = null;
        this.lcs = lcs;
    }

    public LiquidacionesResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.lcs = null;
    }

    public LiquidacionesResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.lcs = null;
    }

    public List<LiquidacionCobranza> getLcs() {
        return lcs;
    }
    /*** SET AND GET ***/
    public void setLcs(List<LiquidacionCobranza> lcs) {
        this.lcs = lcs;
    }
}
