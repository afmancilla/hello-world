package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.DeudaTributariaActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.SplashActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo.RiesgoActivity;

@Module
public abstract class ActivityModule {
    @ContributesAndroidInjector(modules = FragmentBuildersModule.class)
    abstract MainActivity contributeMainActivity();

    @ContributesAndroidInjector(modules = FragmentBuildersDeudaModule.class)
    abstract DeudaTributariaActivity contributeDeudaTributariaActivity();
    @ContributesAndroidInjector
    abstract RiesgoActivity contributeRiesgoActivity();

    @ContributesAndroidInjector
    abstract BaseActivity contributeBaseActivity();

    @ContributesAndroidInjector
    abstract SplashActivity contributeSplashActivity();
}
