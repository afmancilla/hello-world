package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "links",
        "content",
        "page"
})
public class Items {

    @JsonProperty("links")
    private List<Link> links;

    @JsonProperty("content")
    private List<Item> items;

    @JsonProperty("page")
    private Page page;

    private List<Item> itemsFiltrados = new ArrayList<>();
    /*** SET AND GET ***/

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public List<Item> getItemsFiltrados() {
        return itemsFiltrados;
    }

    public void setItemsFiltrados(List<Item> itemsFiltrados) {
        this.itemsFiltrados = itemsFiltrados;
    }
}
