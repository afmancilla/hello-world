package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item;


import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Items;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.adapter.AdapterItemsList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.ItemsViewModel;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import timber.log.Timber;

import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDSERIE;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;


public class ItemFragment extends BaseFragment implements Injectable {
    public static final String TAG = ItemFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_view_items)
    RecyclerView recyclerView;

    private View view;
    private SearchView searchView;
    private AdapterItemsList mAdapter;
    private OnFragmentIterationListener listener;
    private ItemsViewModel viewModel;


    public interface OnFragmentIterationListener {
        void setItemDetalleFragment(Bundle bundle);
    }

    public ItemFragment() {
    }

    public static ItemFragment newInstance(Bundle params) {
        ItemFragment itemFragment = new ItemFragment();
        itemFragment.setArguments(params);
        return itemFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_items_list, container, false);

        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {

        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterItemsList(this.getContext(), new Items(),ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener(new AdapterItemsList.OnItemClickListener() {
            @Override
            public void onItemClick(View view, Item item, int position) {
                if (listener != null) {
                    Bundle params = getArguments();
                    if (params != null) {
                        params.putString(Constantes.ARG_IDITEM, item.getNumSecItem());
                    }
                    listener.setItemDetalleFragment(params);
                }
            }
        });

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(ItemsViewModel.class);


        String token = params.getString(ARG_TOKEN);
        String idDam = params.getString(ARG_IDDAM);
        String idSerie = params.getString(ARG_IDSERIE);

        viewModel.getListaItems( token, idDam, idSerie).observe(this, response ->{

            ((MainActivity)getActivity()).hideMessage();
            Items items = response.getItems();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if(items!=null){
                mAdapter.addItems(items);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                }else if (Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                    ((BaseActivity)getActivity()).showNoFound();
                }else {
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }
        });

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_item, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_buscar).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(!"".equals(searchView.getQueryHint()) &&  !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if(!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }
        });
    }

    public void settleFilterOption(MenuItem item,String hint){
        item.setChecked(true);
        this.searchView.setQueryHint(hint+":");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

            /***FILTRAR***/
            case R.id.submenu_f_nro_item:
                settleFilterOption(item,"NRO ITEM");
                break;
            case R.id.submenu_f_nro_partida:
                settleFilterOption(item,"PARTIDA");
                break;
            case R.id.submenu_f_descr_merca:
                settleFilterOption(item,"DESCRIPCION");
                break;
            case R.id.submenu_f_fob:
                settleFilterOption(item,"FOB");
                break;
            case R.id.submenu_f_proveedor:
                settleFilterOption(item,"PROVEEDOR");
                break;
            case R.id.submenu_f_nro_factura:
                settleFilterOption(item,"NRO FACTURA");
                break;
            case R.id.submenu_f_fecha_factura:
                settleFilterOption(item,"FECHA FACTURA");
                break;

            /***ORDENAR***/
            case R.id.submenu_o_nro_serieitem:
                mAdapter.sorted("ITEM");
                break;
            case R.id.submenu_o_nro_partida:
                mAdapter.sorted("PARTIDA");
                break;
            case R.id.submenu_o_descr_mercaitem:
                mAdapter.sorted("DESCRIPCION");
                break;
        }

        return true;
    }


    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
