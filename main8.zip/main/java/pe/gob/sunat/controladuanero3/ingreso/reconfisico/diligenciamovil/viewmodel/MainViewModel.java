package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.AdvertenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DiligenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.FotoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.AsignacionRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DiligenciaRepository;

public class MainViewModel extends AndroidViewModel {

    public static final String TAG = MainViewModel.class.getSimpleName();

    private MediatorLiveData<FotoResponse> fotoResponse;
    private MediatorLiveData<DiligenciaResponse> diligenciaResponse;
    private MediatorLiveData<AdvertenciaResponse> advertenciaResponse;
    private AsignacionRepository asignacionRepository;
    private DiligenciaRepository diligenciaRepository;
    private DamRepository damRepository;


    @Inject
    public MainViewModel(
            @NonNull Application application,
            @NonNull AsignacionRepository asignacionRepository,
            @NonNull DiligenciaRepository diligenciaRepository,
            @NonNull DamRepository damRepository) {
        super(application);

        this.asignacionRepository = asignacionRepository;
        this.diligenciaRepository = diligenciaRepository;
        this.damRepository = damRepository;
        fotoResponse = new MediatorLiveData<>();
        diligenciaResponse = new MediatorLiveData<>();
        advertenciaResponse = new MediatorLiveData<>();
    }

    public LiveData<FotoResponse> getFoto(String token, String codFuncionario){

        if(fotoResponse.getValue()==null
                || !codFuncionario.equals(fotoResponse.getValue().getCodFuncionario())){
            fotoResponse.addSource(asignacionRepository.getFoto(token,codFuncionario),imagenResponse -> fotoResponse.setValue(imagenResponse));
        }
        return fotoResponse;
    }

    public LiveData<DiligenciaResponse> postDiligencia(String token, Diligencia diligencia, String idDam) {

        diligenciaResponse.addSource(diligenciaRepository.registrarDiligencia(token,diligencia,idDam),response -> diligenciaResponse.setValue(response));

        return diligenciaResponse;
    }
    public LiveData<AdvertenciaResponse> getListaAdvertencias(String token, String idDam, String tipo){

        if(advertenciaResponse.getValue()==null
                || (!(idDam.concat(tipo)).equals((advertenciaResponse.getValue().getIdDam()).concat(advertenciaResponse.getValue().getTipo())))
                )

        {
            advertenciaResponse.addSource(damRepository.getAdvertencias(token,idDam, tipo), advResponse -> advertenciaResponse.setValue(advResponse));
        }

        return advertenciaResponse;
    }
}
