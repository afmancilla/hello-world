package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module;

import android.app.Application;
import android.arch.lifecycle.ViewModelProvider;
import android.content.Context;


import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.BuildConfig;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.RetrofitClient;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.AsignacionApi;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DamApi;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DiligenciaApi;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Session;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.ProjectViewModelFactory;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

@Module(subcomponents = ViewModelSubComponent.class)
public class AppModule {

    @Provides
    @Singleton
    Context provideContext(Application application) {
        return application;
    }

    @Provides
    Session provideSession(Context context){

        return new Session(context);
    }



    @Singleton
    @Provides
    DamApi provideDamApi(Context context)  {

        try {
            return new Retrofit.Builder()
                    .baseUrl(BuildConfig.SUNAT_URL)
                    .client(RetrofitClient.getokhttpclient(context).build())
                    .addConverterFactory(JacksonConverterFactory.create())
                    .build()
                    .create(DamApi.class);
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    @Singleton
    @Provides
    AsignacionApi provideAsignacionApi(Context context)  {

        try {
        return new Retrofit.Builder()
                .baseUrl(BuildConfig.SUNAT_URL)
                .client(RetrofitClient.getokhttpclient(context).build())
                .addConverterFactory(JacksonConverterFactory.create())
                .build()
                .create(AsignacionApi.class);

        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    @Singleton
    @Provides
    DiligenciaApi provideDiligenciaApi(Context context)  {

        try {
            return new Retrofit.Builder()
                    .baseUrl(BuildConfig.SUNAT_URL)
                    .client(RetrofitClient.getokhttpclient(context).build())
                    .addConverterFactory(JacksonConverterFactory.create())
                    .build()
                    .create(DiligenciaApi.class);
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Singleton
    @Provides
    ViewModelProvider.Factory provideViewModelFactory(
            ViewModelSubComponent.Builder viewModelSubComponent) {

        return new ProjectViewModelFactory(viewModelSubComponent.build());
    }
}
