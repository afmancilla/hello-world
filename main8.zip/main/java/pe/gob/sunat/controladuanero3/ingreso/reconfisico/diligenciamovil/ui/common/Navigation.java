package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.common;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;

import javax.inject.Inject;
import javax.inject.Singleton;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.BandejaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.ContenedoresListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DeclaracionFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DocTransporteListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.DeudaTributariaActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia.DiligenciaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.SplashActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo.RiesgoActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieFragment;


public class Navigation {

    private final int containerId;
    private final FragmentManager fragmentManager;
    private final Context context;

    @Inject
    public Navigation(MainActivity mainActivity) {
        this.containerId = R.id.main_fragment_placeholder;
        this.fragmentManager = mainActivity.getSupportFragmentManager();
        this.context = mainActivity.getApplicationContext();
    }

    public void navigateToInitialBandejaFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, BandejaFragment.newInstance(bundle),BandejaFragment.TAG)
                .commit();
    }

    public void navigateToBandejaFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, BandejaFragment.newInstance(bundle),BandejaFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToDiligenciaFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, DiligenciaFragment.newInstance(bundle),DiligenciaFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToDeclaracionFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, DeclaracionFragment.newInstance(bundle),DeclaracionFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToDocTransporteListFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, DocTransporteListFragment.newInstance(bundle),DocTransporteListFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToContenedoresListFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, ContenedoresListFragment.newInstance(bundle),ContenedoresListFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToSeriesFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, SerieFragment.newInstance(bundle),SerieFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToSerieDetalleFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, SerieDetalleFragment.newInstance(bundle),SerieDetalleFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToItemsFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, ItemFragment.newInstance(bundle),ItemFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToItemDetalleFragment(Bundle bundle){

        fragmentManager.beginTransaction()
                .replace(containerId, ItemDetalleFragment.newInstance(bundle),ItemDetalleFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    public void navigateToLogin(){
        Intent intent = new Intent(context, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);

    }

    public void navigateToRiesgo(){
        Intent intent = new Intent(context, RiesgoActivity.class);
        context.startActivity(intent);
    }

    public void navigateToDeuda(){
        Intent intent = new Intent(context, DeudaTributariaActivity.class);
        context.startActivity(intent);
    }
}
