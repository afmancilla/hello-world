package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service;

import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Declaracion;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DeudaTributaria;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Items;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.LiquidacionCobranza;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Riesgo;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;
import retrofit2.Call;
import retrofit2.http.*;




public interface DamApi {
  
  /**
   * Busca la declaración por el ID DAM
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   *
   *@return Call&lt;Declaracion&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}")
  Call<Declaracion> buscarDamPorIdDam(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam
  );

  
  /**
   * Retorna lista las deudas
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param tipo identificador de la deuda tipo LC, Formato C (required)
   * @return Call&lt;DeudaTributaria&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/deudastributariasaduaneras/{tipo}")
  Call<DeudaTributaria> buscarDeudasTributariasAduanerasPorIdDam(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("tipo") String tipo
  );

  
  /**
   * Retorna lista de indicadores de riesgo evaluadas para la DAM
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @return Call&lt;Riesgo&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/riesgos")
  Call<List<Riesgo>> buscarIndicadoresRiesgoPorIdDam(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam
  );

  
  /**
   * retorna el item con el idItem de la declaracion idDam de la serie idSerie
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param numSecSerie identificador de la serie (required)
   * @param numSecItem identificador del item (required)
   * @return Call&lt;List&lt;Item&gt;&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/series/{numSecSerie}/items/{numSecItem}")
  Call<Item> buscarItemsPorID(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("numSecSerie") String numSecSerie,
          @Path("numSecItem") String numSecItem
  );

  
  /**
   * Retorna todas los items de la serie idSerie
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param numSecSerie identificador de la serie (required)
   * @param page el numero de página (optional)
   * @param perPage el numero de registros que nos devuelve cada página (optional)
   * @return Call&lt;List&lt;Item&gt;&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/series/{numSecSerie}/items/")
  Call<Items> buscarItemsPorSerie(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("numSecSerie") String numSecSerie
  );

  
  /**
   * Retorna lista las lc
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @return Call&lt;LiquidacionCobranza&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/liquidacionescobranzas")
  Call<List<LiquidacionCobranza>> buscarLCPorIdDam(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam
  );

  
  /**
   * Retorna la serie por idSerie
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param numSecSerie identificador de la serie (required)
   * @return Call&lt;Serie&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/series/{numSecSerie}")
  Call<Serie> buscarSeriesPorID(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("numSecSerie") String numSecSerie
  );

  
  /**
   * Retorna todas las series de la declaracion
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param page el numero de página (optional)
   * @param perPage el numero de registros que nos devuelve cada página (optional)
   * @return Call&lt;PagedSeries&gt;
   *///se cambia a series anita
  @GET("/v1/controladuanero/declaraciones/{idDam}/series")
  Call<Series> buscarSeriesPorIdDam(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam
  );

  
  /**
   * Retorna todas las advertencias que tiene la declaración
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param tipo identificador del tipo de validacion (required)
   * @return Call&lt;Advertencia&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/advertencias/{tipo}")
  Call<List<Advertencia>> validarDAMParaDiligenciaMovil(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("tipo") String tipo
  );
  
}

