package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Declaracion;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import timber.log.Timber;


public class DeclaracionResponse extends BaseResponse{
    private Declaracion dam;

    /*** CONSTRUCTORES ***/
    public DeclaracionResponse(Declaracion dam) {
        this.dam = dam;
        this.error = null;
        this.errorGeneral = null;
    }

    public DeclaracionResponse(Throwable error) {
        this.error = error;
        this.dam = null;
        this.errorGeneral = null;

        Timber.e("Throwable:%s", error.getStackTrace());
    }

    public DeclaracionResponse(ErrorGeneral errorGeneral) {
        this.errorGeneral = errorGeneral;
        this.error = null;
        this.dam = null;

        Timber.e("ErrorGeneral -> codigo:%s, mensaje:%s, trace:%s", errorGeneral.getCod(),errorGeneral.getMsg(),errorGeneral.getExc());
    }

    /***SET AND GET***/

    public Declaracion getDam() {
        return dam;
    }

    public void setDam(Declaracion dam) {
        this.dam = dam;
    }
}
