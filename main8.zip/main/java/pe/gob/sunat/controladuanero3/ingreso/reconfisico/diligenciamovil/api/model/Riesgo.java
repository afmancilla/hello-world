
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * Riesgo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "modelo",
        "series",
        "fraude",
        "detalle"
})
public class Riesgo {


    @JsonProperty("modelo")
    private String modelo;

    @JsonProperty("series")
    private String series;

    @JsonProperty("fraude")
    private String fraude;

    @JsonProperty("detalle")
    private String detalle;

    /******************* GET AND SET ***********************/
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public String getFraude() {
        return fraude;
    }

    public void setFraude(String fraude) {
        this.fraude = fraude;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }
}



