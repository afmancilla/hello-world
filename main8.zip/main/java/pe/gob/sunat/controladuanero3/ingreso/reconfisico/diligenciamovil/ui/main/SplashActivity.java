package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;

import android.util.Base64;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

import butterknife.BindView;

import dagger.android.AndroidInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.BuildConfig;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;


public class SplashActivity extends BaseActivity {


    @BindView(R.id.shimmer_view_container)
    ShimmerFrameLayout shimmer;

    @BindView(R.id.splash)
    ConstraintLayout splash;

    private String eToken;
    private String eUsuario;

    private AccountManager accountManager;
    public static final String[] columnas = new String[]{"_id", "usuario", "token"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidInjection.inject(this);
        shimmer.setAutoStart(true);
        accountManager = AccountManager.get(this);

        session.setClientIdSunat(BuildConfig.CLIENT_ID);
        session.setClientSecretSunat(BuildConfig.CLIENT_SECRET);
        eUsuario = getIntent().getStringExtra("usuario");
        eToken = getIntent().getStringExtra("token");

        if (eToken != null && eUsuario != null && validarToken2(eUsuario, eToken)) { //invoca Login del Autenticador y devuelve
            intentBandeja(eUsuario, eToken);
        } else { //primera ejecucion

            new ConfigApp().execute();
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_splash;
    }

    /**
     * Async Task to make HTTP calls.
     */
    private class ConfigApp extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            // This is called before sending actual HTTP call...
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            // Write the code here to make HTTP calls....
            // For the sake of simplicity of the post, I am only mentioning what to write here and not the actual code.
            // Once your HTTP calls are complete, onPostExecute method will be called with the intended result.
/*
            try {
                Thread.sleep(3 * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            // This method will be called after completion of HTTP call. So, Retrieve the intended data
            // and start the main activity. You can also pass this data to main activity using putExtra or
            // some similar methods.
            // Make sure you close this activity after starting MainActivity.


            Account cuentas[] = accountManager.getAccountsByType(Constantes.ACCOUNT_TYPE);

            int numCuentasRegistradas = cuentas.length;
            if (numCuentasRegistradas > 1) {
                //mostrarListaCuentas(cuentas);
                intentLoginAppAutenticador();
            } else if (numCuentasRegistradas == 1) {
                Account cuenta = cuentas[0];
                validarToken(cuenta);
            } else {
                intentLoginAppAutenticador();
            }

        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //View localView = findViewById(R.id.splash);
        if (splash != null) {
            splash.setBackgroundDrawable(null);
        }
    }

    private void validarToken(Account cuenta) {


        String[] parts = cuenta.name.split("(?=-)");
        eUsuario = parts[0];

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(Constantes.CONTENT_URI,
                columnas, //Columnas a devolver
                "usuario=?",      //Condición de la query
                new String[]{eUsuario},//Argumentos variables de la query
                null);      //Orden de los resultados

        //Verifica en BD
        if (cur.moveToFirst()) {
            String usuario = cur.getString(cur.getColumnIndex("usuario"));
            eToken = cur.getString(cur.getColumnIndex("token"));
            if (eToken != null && !eToken.isEmpty()) {
                intentBandeja(usuario, eToken);
            } else {
                intentLoginAppAutenticador();
            }
        } else {
            intentLoginAppAutenticador();
        }
    }


    private void intentLoginAppAutenticador() {
        Intent intentLogin = getPackageManager().getLaunchIntentForPackage(Constantes.AUTHENTICATOR_PACKAGE);
        if (intentLogin != null) {
            intentLogin.putExtra(Constantes.KEY_APLICATION_PRINCIPAL, Constantes.APLICATION_PRINCIPAL);
            intentLogin.putExtra(Constantes.KEY_CLIENT_ID, session.getClientIdSunat());
            intentLogin.putExtra(Constantes.KEY_CLIENT_SECRET, session.getClientSecretSunat());
            startActivity(intentLogin);
            finish();
        } else {
            Toast.makeText(getBaseContext(), "INSTALAR EL APK AUTHENTICADOR - IR A LA GOOGLE PLAY", Toast.LENGTH_LONG).show();
        }
    }

    private void intentBandeja(String usuario, String token) {
        session.setUsuario(usuario);
        session.setLogin(true);
        guardarTokenPreferencia(token);

        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
        finish();
    }

    private boolean validarToken2(String eUsuario, String eToken) {

        boolean token = false;

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(Constantes.CONTENT_URI,
                columnas, //Columnas a devolver
                "usuario=?",      //CondiciÃ³n de la query
                new String[]{eUsuario},//Argumentos variables de la query
                null);      //Orden de los resultados

        //Verifica en BD
        if (cur.moveToFirst()) {
            String usuario = cur.getString(cur.getColumnIndex("usuario"));
            eToken = cur.getString(cur.getColumnIndex("token"));
            if (eToken != null && !eToken.isEmpty()) {
                return true;
            }
        }

        return token;
    }

    private void guardarTokenPreferencia(String token) {

        String[] split = token.split("\\.");
        byte[] data = Base64.decode(split[1], Base64.URL_SAFE);
        String text = new String(data, StandardCharsets.UTF_8);

        JSONObject jsonData;
        JSONObject userJson;
        try {
            jsonData = new JSONObject(text);
            userJson = jsonData.getJSONObject("userdata");

            session.setNombreCompleto(userJson.getString("nombreCompleto"));
            session.setToken(token);
            session.setCodArea(userJson.getString("codUO"));
            session.setCorreo(userJson.getString("correo"));
            session.setCodFuncionario(userJson.getString("nroRegistro"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
