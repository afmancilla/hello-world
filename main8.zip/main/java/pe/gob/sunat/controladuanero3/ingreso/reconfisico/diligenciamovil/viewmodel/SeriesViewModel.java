package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.SeriesResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;

public class SeriesViewModel extends AndroidViewModel {

    public static final String TAG = SeriesViewModel.class.getSimpleName();


    private DamRepository damRepository;
    private MediatorLiveData<SeriesResponse> seriesResponse;


    @Inject
    public SeriesViewModel(@NonNull Application application,
                           @NonNull DamRepository damRepository
    ) {
        super(application);

        this.damRepository = damRepository;
        seriesResponse = new MediatorLiveData<>();
    }



    public LiveData<SeriesResponse> getListaSeries (String token, String idDam){
        if(seriesResponse.getValue() == null){
            seriesResponse.addSource(damRepository.getListSeries(token, idDam), serResponse -> seriesResponse.setValue(serResponse));
        }
        return seriesResponse;
    }
}
