package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class AdvertenciaResponse extends BaseResponse {

    private List<Advertencia> advertencias;
    private String idDam;
    private String tipo;

    public AdvertenciaResponse(List<Advertencia> advertencias,String idDam,String tipo) {
        this.error = null;
        this.errorGeneral = null;
        this.advertencias = advertencias;
        this.idDam = idDam;
        this.tipo= tipo;
    }

    public AdvertenciaResponse(ErrorGeneral errorGeneral) {
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.advertencias = null;
    }

    public AdvertenciaResponse(Throwable error) {
        this.error = error;
        this.errorGeneral = null;
        this.advertencias = null;
    }

    public List<Advertencia> getAdvertencias() {
        return advertencias;
    }

    public void setAdvertencias(List<Advertencia> advertencias) {
        this.advertencias = advertencias;
    }

    public String getIdDam() {
        return idDam;
    }

    public String getTipo() {
        return tipo;
    }
}
