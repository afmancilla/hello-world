package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Contenedor;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Declaracion;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentoTransporte;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.DeclaracionViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import timber.log.Timber;


import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;


public class DeclaracionFragment extends Fragment implements Injectable {

    public static final String TAG = DeclaracionFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.linear_layout_doc_transportes)
    LinearLayout docTransporteList;

    @BindView(R.id.linear_layout_contenedores)
    LinearLayout contenedorList;

    @BindView(R.id.text_view_modalidad)
    TextView textViewModalidad;
    @BindView(R.id.text_view_categoria)
    TextView textViewCategoria;
    @BindView(R.id.text_view_consignatario)
    TextView textViewConsignatario;
    @BindView(R.id.text_view_agente_aduana)
    TextView textViewAgenteAduana;
    @BindView(R.id.text_view_fob)
    TextView textViewFob;
    @BindView(R.id.text_view_flete)
    TextView textViewFlete;
    @BindView(R.id.text_view_seguro)
    TextView textViewSeguro;
    @BindView(R.id.text_view_peso_bruto)
    TextView textViewPesoBruto;
    @BindView(R.id.text_view_cantidad_bultos)
    TextView textViewCantidadBultos;
    @BindView(R.id.ind_img_gar160)
    ImageView indViewGarantia160;
    @BindView(R.id.ind_img_oea)
    ImageView indViewOea;

    private OnFragmentIterationListener listener;
    private DeclaracionViewModel viewModel;

    private View view;
    private List<DocumentoTransporte> transportes = new ArrayList<>();
    private List<Contenedor> contenedores = new ArrayList<>();

   Unbinder unbinder;

    public DeclaracionFragment() {
    }


    public static DeclaracionFragment newInstance(Bundle params) {
        DeclaracionFragment df = new DeclaracionFragment();
        df.setArguments(params);
        return df;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this,viewModelFactory).get(DeclaracionViewModel.class);

        String token = getArguments().getString(ARG_TOKEN);
        String idDam = getArguments().getString(ARG_IDDAM);

        viewModel.getDam(token, idDam).observe(this, response -> {

            ((BaseActivity)getActivity()).hideMessage();
            Declaracion dam = response.getDam();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if(dam!=null){
                cargarPantalla(dam);
                transportes = new ArrayList<>();
                contenedores = new ArrayList<>();
                transportes.addAll(dam.getDocumentosTransporte());
                contenedores.addAll(dam.getContenedores());
            }else if(error!=null){
                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                }else {
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if(throwable!=null){
                Timber.e(throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }

        });

    }

    private void cargarPantalla(Declaracion dam) {

        if(dam.getTieneGarantia160()){
            indViewGarantia160.setVisibility(View.VISIBLE);
        }else{
            indViewGarantia160.setVisibility(View.INVISIBLE);
        }

        if(dam.getEsOEA()){
            indViewOea.setVisibility(View.VISIBLE);
        }else{
            indViewOea.setVisibility(View.INVISIBLE);
        }

        textViewModalidad.setText(dam.getModalidad().getCodDesc());
        textViewCategoria.setText(dam.getCodCategoria());
        textViewConsignatario.setText(dam.getConsignatario().getRucRazonSocial());
        textViewAgenteAduana.setText(dam.getAgenteAduana().getRucRazonSocial());

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        symbols.setDecimalSeparator('.');
        DecimalFormat decimalFormat = new DecimalFormat("US$ #,###.00", symbols);

        textViewFob.setText(decimalFormat.format(dam.getMtoTotFobDol()!=null?dam.getMtoTotFobDol():0));
        textViewFlete.setText(decimalFormat.format(dam.getMtoTotFleteDol()!=null?dam.getMtoTotFleteDol():0));
        textViewSeguro.setText(decimalFormat.format(dam.getMtoTotSegDol()!=null?dam.getMtoTotSegDol():0));
        textViewPesoBruto.setText(dam.getCntPesoBrutoTotal().toString());
        textViewCantidadBultos.setText(dam.getCntTotBultos().toString());


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_declaracion, container, false);
        unbinder = ButterKnife.bind(this, view);

        docTransporteList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    Bundle bundle = getArguments();
                    bundle.putSerializable(Constantes.ARG_LIST_DOCTRANSPORTES,(Serializable) transportes);

                    listener.setDocTransporteListFragment(bundle);
                }
            }
        });

        contenedorList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    Bundle bundle = getArguments();
                    bundle.putSerializable(Constantes.ARG_LIST_CONTENEDORES,(Serializable) contenedores);

                    listener.setContenedoresListFragment(bundle);
                }
            }
        });

        return view;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }


    public interface OnFragmentIterationListener {
        void setDocTransporteListFragment(Bundle bundle);

        void setContenedoresListFragment(Bundle bundle);
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Timber.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
