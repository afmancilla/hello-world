package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository;


import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;



import javax.inject.Inject;
import javax.inject.Singleton;

import okhttp3.ResponseBody;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DocumentoAsignadoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.FotoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.AsignacionApi;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
@Singleton
public class AsignacionRepository {

    private final static String TAG = AsignacionRepository.class.getSimpleName();

    private AsignacionApi asignacionApi;

    @Inject
    public AsignacionRepository(AsignacionApi asignacionApi) {
        this.asignacionApi =  asignacionApi;
    }

    public LiveData<DocumentoAsignadoResponse> getListDocumentosAsignados(String token, String codFuncionario){

        final MutableLiveData<DocumentoAsignadoResponse> docAsignadoResponse = new MutableLiveData<>();

        asignacionApi.buscarDocumentosAsignadosPorFuncionario("Bearer " + token, codFuncionario,"01").enqueue(new Callback<DocumentosAsignados>() {
            @Override
            public void onResponse(Call<DocumentosAsignados> call, Response<DocumentosAsignados> response) {

                if (response.isSuccessful()) {
                    docAsignadoResponse.postValue(new DocumentoAsignadoResponse(response.body()));
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(response.code());
                    errorGeneral.setMsg(response.message());
                    errorGeneral.setExc(response.toString());
                    docAsignadoResponse.postValue(new DocumentoAsignadoResponse(errorGeneral));
                }
            }
            @Override
            public void onFailure(Call<DocumentosAsignados> call, Throwable t) {
                docAsignadoResponse.postValue(new DocumentoAsignadoResponse(t));
            }
        });

        return docAsignadoResponse;
    }

    public LiveData<FotoResponse> getFoto(String token, String codFuncionario){

        final MutableLiveData<FotoResponse> fotoResponse = new MutableLiveData<>();


        asignacionApi.buscarFotoFuncionarioPorCodigo("Bearer " + token, codFuncionario).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    fotoResponse.postValue(new FotoResponse(response.body(),codFuncionario));
                }else{
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(response.code());
                    errorGeneral.setMsg(response.message());
                    errorGeneral.setExc(response.toString());
                    fotoResponse.postValue(new FotoResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                fotoResponse.postValue(new FotoResponse(t));
            }
        });

        return fotoResponse;
    }
}
