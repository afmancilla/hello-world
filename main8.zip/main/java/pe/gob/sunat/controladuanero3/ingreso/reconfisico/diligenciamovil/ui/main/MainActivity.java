package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main;

import android.app.Dialog;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import dagger.android.AndroidInjection;
import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import okhttp3.ResponseBody;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Error;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.BandejaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.common.Navigation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DeclaracionFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia.DiligenciaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.MainViewModel;
import timber.log.Timber;

public class MainActivity extends BaseActivity
        implements
        HasSupportFragmentInjector,
        BandejaFragment.OnFragmentIterationListener,
        DiligenciaFragment.OnFragmentIterationListener,
        DeclaracionFragment.OnFragmentIterationListener,
        SerieFragment.OnFragmentIterationListener,
        SerieDetalleFragment.OnFragmentIterationListener,
        ItemFragment.OnFragmentIterationListener,
        ItemDetalleFragment.OnFragmentIterationListener {

    public static final String TAG = MainActivity.class.getSimpleName();

    @Inject
    DispatchingAndroidInjector<Fragment> dispatchingAndroidInjector;

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @Inject
    Navigation navigation;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.bottom_navigation_view_dam)
    BottomNavigationView bottomNavigationViewDam;

    @BindView(R.id.nav_view)
    NavigationView navView;

    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;

    private ActionBar actionBar;
    private MainViewModel viewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidInjection.inject(this);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(MainViewModel.class);

        if (!session.isLoggedIn()) {
            showTokenDialog();
        }

        initToolbarHome();
        setInitialFragment();
        cargarDatosUsuario();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    private void setInitialFragment() {


        Bundle bundle = new Bundle();
        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_BANDEJA));
            //desactivamos la declaracion en session
            session.setIdDAM("");
            session.setIdSERIE("");
            session.setIdITEM("");
        }

        showLoading();
        activeNavigation(Constantes.ARG_TITULO_BANDEJA);
        navigation.navigateToInitialBandejaFragment(bundle);

        bottomNavigationViewDam.setOnNavigationItemSelectedListener(item -> {

            boolean marca = true;
            switch (item.getItemId()) {
                case R.id.navigation_bandeja:
                    setBandejaFragment(bundle);
                    break;
                case R.id.navigation_dam:
                    setDeclaracionFragment(bundle);
                    break;
                case R.id.navigation_series:
                    setSeriesFragment(bundle);
                    break;
                case R.id.navigation_diligencia:
                    initPantallaDiligencia(bundle);
                    marca = false;
                    break;
            }
            return marca;
        });

    }


    private void initPantallaDiligencia(Bundle bundle) {

        String token = session.getToken();
        String idDam = session.getIdDAM();


        viewModel.getListaAdvertencias(token,idDam,Constantes.ARG_TIPO_ADVERTENCIA_DILIGENCIA).observe(this,response -> {

            List<Advertencia> advertencias = response.getAdvertencias();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if(advertencias!=null){
                if(advertencias.size()==0){
                    setDiligenciaFragment(bundle);
                }else{
                    mostrarAdvertencias(advertencias,idDam);
                }
            }else if(error!=null){
                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else {
                    Timber.e(errorMsg);
                    showErrorMessage(errorMsg);
                }
            }else if(throwable!=null){
                Timber.e(throwable.getMessage());
                showErrorMessage(throwable.getMessage());
            }
        });

    }

    private void initToolbarHome() {

        toolbar.setNavigationIcon(R.drawable.ic_menu);
        setSupportActionBar(toolbar);

        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        Tools.setSystemBarColor(this);
        initNavigationMenu();
    }

    private void initToolbarBack() {

        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);
    }


    private void initNavigationMenu() {

        MenuItem navItemDeuda = navView.getMenu().findItem(R.id.nav_deuda);
        MenuItem navItemRiezgo = navView.getMenu().findItem(R.id.nav_riesgo);

        if(session.getIdDAM().trim().isEmpty()){
            navItemDeuda.setEnabled(false);
            navItemRiezgo.setEnabled(false);
        }else{
            navItemDeuda.setEnabled(true);
            navItemRiezgo.setEnabled(true);
        }

        String codFuncionario = session.getCodFuncionario();
        viewModel.getFoto(session.getToken(), codFuncionario).observe(this, response -> {

            ResponseBody body = response.getResponseBody();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if (body != null) {
                downloadFoto(body,codFuncionario);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else if(Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                    showInfoMessage("No se encontro foto");
                }else {
                    Timber.e(errorMsg);
                    showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                showErrorMessage(throwable.getMessage());
            }
        });


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };
        drawerLayout.setDrawerListener(toggle);
        toggle.syncState();
        navView.setNavigationItemSelectedListener(item -> {
            drawerLayout.closeDrawers();
            displayView(item.getItemId());
            return true;
        });

    }

    private void downloadFoto(ResponseBody body, String codFuncionario) {

        Bitmap bitmap = Tools.getFoto(body,codFuncionario,this);
            ImageView image_view_foto = navView.getHeaderView(0).findViewById(R.id.image_view_foto);

        if (bitmap != null) {
                image_view_foto.setImageBitmap(Bitmap.createScaledBitmap(bitmap, 90, 100, true));
            }
    }

    private void displayView(int viewId) {
        switch (viewId) {

            case R.id.nav_riesgo:
                navigation.navigateToRiesgo();
                break;
            case R.id.nav_deuda:
                navigation.navigateToDeuda();
                break;
            case R.id.nav_salir:
                showLogoutDialog();
                break;
        }
    }



    private void cargarDatosUsuario() {
        TextView nombreCompleto = navView.getHeaderView(0).findViewById(R.id.text_view_fullname);
        TextView email          = navView.getHeaderView(0).findViewById(R.id.text_view_email);

        nombreCompleto.setText(session.getNombreCompleto());
        email.setText(session.getCorreo());
    }


    public void setBandejaFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_BANDEJA));
            //desactivamos la declaracion en session
            session.setIdDAM("");
            session.setIdSERIE("");
            session.setIdITEM("");
        }else{
            showTokenDialog();
        }
        initToolbarHome();
        activeNavigation(Constantes.ARG_TITULO_BANDEJA);
        showLoading();
        navigation.navigateToBandejaFragment(bundle);
    }

    public void setDiligenciaFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_DILIGENCIA));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarHome();
        activeNavigation(Constantes.ARG_TITULO_DILIGENCIA);
        //showLoading();
        navigation.navigateToDiligenciaFragment(bundle);
    }

    public void setSeriesFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_SERIES));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarHome();
        activeNavigation(Constantes.ARG_TITULO_SERIES);
        showLoading();
        navigation.navigateToSeriesFragment(bundle);
    }

    @Override
    public void setDeclaracionFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            if (bundle != null && bundle.getString(Constantes.ARG_IDDAM) != null) {
                session.setIdDAM(bundle.getString(Constantes.ARG_IDDAM));
            }else{
                session.setIdDAM("");
            }
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarHome();
        activeNavigation(Constantes.ARG_TITULO_DAM);
        showLoading();
        navigation.navigateToDeclaracionFragment(bundle);
    }

    @Override
    public void grabarDiligencia(Bundle bundle) {

        showLoading();

        Diligencia diligencia = new Diligencia();
        diligencia.setCntBultosRecon(bundle.getString(Constantes.ARG_CNT_BULTOSRECON));
        diligencia.setCodFuncionario(session.getCodFuncionario());
        diligencia.setDesResultado(bundle.getString(Constantes.ARG_DES_RESULTADO));
        diligencia.setFecDiligencia(bundle.getString(Constantes.ARG_FEC_RECONFISICO));

        viewModel.postDiligencia(session.getToken(), diligencia, session.getIdDAM()).observe(this, response -> {

            Diligencia ok = response.getDiligencia();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if (ok != null) {
                hideMessage();
                showSuccesDialog();
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    showTokenDialog();
                }else if (Constantes.ERROR_VALIDACION.equals(error.getCod())){
                    Timber.i(errorMsg);
                    mostrarAlertas(error);
                }else {
                    Timber.e(errorMsg);
                    showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                showErrorMessage(throwable.getMessage());
            }
        });

    }



    @Override
    public void setDocTransporteListFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_DOCUTRANS));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }

        initToolbarBack();
        //no es necesario showLoading();
        navigation.navigateToDocTransporteListFragment(bundle);
        toolbar.setNavigationOnClickListener(v -> setDeclaracionFragment(bundle));
    }

    @Override
    public void setContenedoresListFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_CONTENEDORES));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }

        initToolbarBack();
        //no es necesario showLoading();
        navigation.navigateToContenedoresListFragment(bundle);
        toolbar.setNavigationOnClickListener(v -> setDeclaracionFragment(bundle));
    }

    @Override
    public void setSerieDetalleFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            if (bundle != null && bundle.getString(Constantes.ARG_IDSERIE) != null) {
                session.setIdSERIE(bundle.getString(Constantes.ARG_IDSERIE));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_SERIE));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarBack();
        showLoading();
        navigation.navigateToSerieDetalleFragment(bundle);
        toolbar.setNavigationOnClickListener(v -> setSeriesFragment(bundle));
    }

    @Override
    public void setItemsFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            if (bundle != null && bundle.getString(Constantes.ARG_IDSERIE) != null) {
                session.setIdSERIE(bundle.getString(Constantes.ARG_IDSERIE));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_ITEMS));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarBack();
        showLoading();
        navigation.navigateToItemsFragment(bundle);
        toolbar.setNavigationOnClickListener(v -> setSerieDetalleFragment(bundle));
    }

    @Override
    public void setItemDetalleFragment(Bundle bundle) {

        if (session.isLoggedIn()) {
            bundle.putString(Constantes.ARG_TOKEN, session.getToken());
            bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
            bundle.putString(Constantes.ARG_IDDAM, session.getIdDAM());
            bundle.putString(Constantes.ARG_IDSERIE, session.getIdSERIE());
            if (bundle != null && bundle.getString(Constantes.ARG_IDITEM) != null) {
                session.setIdITEM(bundle.getString(Constantes.ARG_IDITEM));
            }
            bundle.putString(Constantes.SUB_TITULO, session.getTitulo(Constantes.ARG_TITULO_ITEM));
            getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_DAM));
        }else{
            showTokenDialog();
        }
        initToolbarBack();
        showLoading();
        navigation.navigateToItemDetalleFragment(bundle);
        toolbar.setNavigationOnClickListener(v -> setItemsFragment(bundle));
    }

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return dispatchingAndroidInjector;
    }


    private void activeNavigation(String tipo) {

        if(Constantes.ARG_TITULO_BANDEJA.equals(tipo)){
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(false);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(false);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(false);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setChecked(true);
        }else if (Constantes.ARG_TITULO_DAM.equals(tipo)){
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setChecked(true);

        }else if (Constantes.ARG_TITULO_SERIES.equals(tipo)){
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setChecked(true);
        }else if (Constantes.ARG_TITULO_DILIGENCIA.equals(tipo)){
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_series).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_dam).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_bandeja).setEnabled(true);
            bottomNavigationViewDam.getMenu().findItem(R.id.navigation_diligencia).setChecked(true);
        }

        MenuItem navItemDeuda = navView.getMenu().findItem(R.id.nav_deuda);
        MenuItem navItemRiezgo = navView.getMenu().findItem(R.id.nav_riesgo);
        if(session.getIdDAM().trim().isEmpty()){
            navItemDeuda.setEnabled(false);
            navItemRiezgo.setEnabled(false);
        }else{
            navItemDeuda.setEnabled(true);
            navItemRiezgo.setEnabled(true);
        }
    }



    private void mostrarAlertas(Object objAlert) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_advertencias);
        dialog.setCancelable(true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        ((TextView)(dialog.findViewById(R.id.idDam))).setText(session.getIdDAM());
        String textoAdvertencia = "";
        if(objAlert instanceof ErrorGeneral) {
            ErrorGeneral error = (ErrorGeneral) objAlert;
            if (error.getErrors() != null && error.getErrors().size() > 0) {
                for (Error errorVal : error.getErrors()) {
                    textoAdvertencia = textoAdvertencia.concat(errorVal.getMsg() + "\n");
                }
            } else {
                textoAdvertencia = error.getMsg();
            }
        }else if(objAlert instanceof List){
            List<Advertencia> lstAdvertencias = (List<Advertencia>)objAlert;
            for (Advertencia advertencia : lstAdvertencias) {
                textoAdvertencia = textoAdvertencia.concat(advertencia.getDetalle() + "\n");
            }
        }
        ((TextView)(dialog.findViewById(R.id.advertencias))).setText(textoAdvertencia);
        ((ImageButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                hideMessage();
            }
        });
        ((Button) dialog.findViewById(R.id.bt_Continuar)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Bundle bundle = new Bundle();
                if (session.isLoggedIn()) {
                    bundle.putString(Constantes.ARG_TOKEN, session.getToken());
                    bundle.putString(Constantes.ARG_COD_FUNCIONARIO, session.getCodFuncionario());
                    getSupportActionBar().setTitle(session.getTitulo(Constantes.ARG_TITULO_BANDEJA));
                }
                setBandejaFragment(bundle);
            }
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }


    private void mostrarAdvertencias(List<Advertencia> lstAdvertencias,String idDam){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_advertencias);


        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        ((TextView)(dialog.findViewById(R.id.idDam))).setText(idDam);

        String textoAdvertencia = "";
        for (Advertencia advertencia : lstAdvertencias) {
            textoAdvertencia = textoAdvertencia.concat(advertencia.getDetalle() + "\n");
        }

        ((TextView)(dialog.findViewById(R.id.advertencias))).setText(textoAdvertencia);

        ((Button)dialog.findViewById(R.id.bt_Continuar)).setText("Aceptar");

        (dialog.findViewById(R.id.bt_close)).setOnClickListener((View v) -> dialog.dismiss());

        (dialog.findViewById(R.id.bt_Continuar)).setOnClickListener((View v) -> {
            dialog.dismiss();
        });


        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

}
