package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module;

import dagger.Subcomponent;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.BandejaViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.DeclaracionViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.DeudaViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.ItemViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.ItemsViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.LiquidacionesViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.MainViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.RiesgoViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.SerieViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.SeriesViewModel;

@Subcomponent
public interface ViewModelSubComponent {
    @Subcomponent.Builder
    interface Builder {
        ViewModelSubComponent build();
    }

    BandejaViewModel bandejaViewModel();
    MainViewModel mainViewModel();
    LiquidacionesViewModel liquidacionesViewModel();
    DeudaViewModel deudaViewModel();

    SeriesViewModel seriesViewModel();
    SerieViewModel serieViewModel();

    RiesgoViewModel riesgoViewModel();

    ItemsViewModel itemsViewModel();

    ItemViewModel itemViewModel();

    DeclaracionViewModel declaracionViewModel();
}
