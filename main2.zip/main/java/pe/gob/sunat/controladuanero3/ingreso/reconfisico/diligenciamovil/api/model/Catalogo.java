
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * Catalogo
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "cod",
        "desc",
        "codDesc"
})
public class Catalogo {

    @JsonProperty("cod")
    private String cod;
    @JsonProperty("desc")
    private String desc;
    @JsonProperty("codDesc")
    private String codDesc;

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCodDesc() {
        return codDesc;
    }

    public void setCodDesc(String codDesc) {
        this.codDesc = codDesc;
    }
}



