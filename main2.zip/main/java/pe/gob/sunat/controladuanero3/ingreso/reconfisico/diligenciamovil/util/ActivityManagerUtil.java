package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ActivityManagerUtil {

    // Lista de todas las actividades donde navega el usuario
    private static List<Activity> activityList = new ArrayList<>();

    public static void addActivity(Activity activity) {
        if(activityList==null) {
            activityList = new ArrayList<>();
        }

        if(activity!=null) {
            activityList.add(activity);
        }
    }

    // finaliza el activiy se saca de la lista
    public static void finishActivity(Activity activity) {
        if(activityList!=null) {
            if(activity!=null && activityList.contains(activity)) {
                activity.finish();
                activityList.remove(activity);
            }
        }
    }

    // finaliza la aplicacion
    public static void finishAllActivity() {
        if(activityList!=null) {
            activityList.forEach(activity -> {
                activity.finish();
            });
            activityList.forEach(activity -> {
                activityList.remove(activity);
            });
        }
    }

    // Print all activity info in current task back stack.
    public static void printCurrentTaskActivityList(Context context, String tagName)
    {
        ActivityManager activityManager = (ActivityManager) context.getSystemService( context.ACTIVITY_SERVICE );

        List<ActivityManager.AppTask> appTaskList = activityManager.getAppTasks();

        if(appTaskList!=null) {
            int size = appTaskList.size();
            for(int i=0;i<size;i++)
            {
                ActivityManager.AppTask appTask = appTaskList.get(i);
                ActivityManager.RecentTaskInfo recentTaskInfo = appTask.getTaskInfo();

                int taskId = recentTaskInfo.persistentId;

                int activityNumber = recentTaskInfo.numActivities;

                ComponentName origActivity = recentTaskInfo.origActivity;

                ComponentName baseActivity = recentTaskInfo.baseActivity;

                ComponentName topActivity = recentTaskInfo.topActivity;

                Log.d(tagName, "Task Id : " + taskId);
                Log.d(tagName, "Activity Number : " + activityNumber);

                if(origActivity!=null) {
                    Log.d(tagName, "Original Activity : " + origActivity.toString());
                }

                if(baseActivity!=null) {
                    Log.d(tagName, "Base Activity : " + baseActivity.toString());
                }

                if(topActivity!=null) {
                    Log.d(tagName, "Top Activity : " + topActivity.toString());
                }

                Log.d(tagName, "************************************************");
            }
        }
    }
}
