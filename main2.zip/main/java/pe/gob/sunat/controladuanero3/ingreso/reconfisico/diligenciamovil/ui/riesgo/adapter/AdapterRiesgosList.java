package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.riesgo.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;


import java.util.List;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Riesgo;


public class AdapterRiesgosList extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private List<Riesgo> riesgos;
    private Context ctx;


    public AdapterRiesgosList(Context ctx, List<Riesgo> riesgos) {
        this.riesgos = riesgos;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_riesgos_list,parent,false);
         vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if(holder instanceof  OriginalViewHolder){
            final OriginalViewHolder view = (OriginalViewHolder) holder;
            final Riesgo riesgo = riesgos.get(position);
            view.modelo.setText(riesgo.getModelo());
            view.series.setText(" SERIE(S) "+riesgo.getSeries());
            view.detalle.setText(riesgo.getDetalle());
            view.fraude.setText(riesgo.getFraude());
        }
    }

    @Override
    public int getItemCount() {
        return riesgos!=null ? riesgos.size() : 0;
    }

    private class OriginalViewHolder extends RecyclerView.ViewHolder {

        public TextView modelo, series, fraude, detalle;


        public OriginalViewHolder(View v) {
            super(v);

            modelo = v.findViewById(R.id.text_view_modelo);
            series = v.findViewById(R.id.text_view_series);
            fraude = v.findViewById(R.id.text_view_fraude);
            detalle = v.findViewById(R.id.text_view_detalle);
        }
    }

}