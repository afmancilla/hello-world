package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;
import android.support.v4.util.ArrayMap;


import java.util.Map;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module.ViewModelSubComponent;

@Singleton
public class ProjectViewModelFactory implements ViewModelProvider.Factory{
    private final Map<Class<? extends ViewModel>, Provider<ViewModel>> creators;

    @Inject
    public ProjectViewModelFactory(ViewModelSubComponent viewModelSubComponent) {
        creators = new ArrayMap<>();
        creators.put(BandejaViewModel.class,()-> viewModelSubComponent.bandejaViewModel());
        creators.put(MainViewModel.class,()->viewModelSubComponent.mainViewModel());
        creators.put(DeudaViewModel.class,()->viewModelSubComponent.deudaViewModel());
        creators.put(LiquidacionesViewModel.class,()->viewModelSubComponent.liquidacionesViewModel());
        creators.put(SeriesViewModel.class,()->viewModelSubComponent.seriesViewModel());
        creators.put(SerieViewModel.class,()->viewModelSubComponent.serieViewModel());
        creators.put(RiesgoViewModel.class,()->viewModelSubComponent.riesgoViewModel());
        creators.put(ItemsViewModel.class,()->viewModelSubComponent.itemsViewModel());
        creators.put(ItemViewModel.class,()->viewModelSubComponent.itemViewModel());
        creators.put(DeclaracionViewModel.class,()->viewModelSubComponent.declaracionViewModel());


    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        Provider<? extends ViewModel> creator = creators.get(modelClass);
        if (creator == null) {
            for (Map.Entry<Class<? extends ViewModel>, Provider<ViewModel>> entry : creators.entrySet()) {
                if (modelClass.isAssignableFrom(entry.getKey())) {
                    creator = entry.getValue();
                    break;
                }
            }
        }
        if (creator == null) {
            throw new IllegalArgumentException("unknown model class " + modelClass);
        }
        try {
            return (T) creator.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
