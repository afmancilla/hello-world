package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;


public class SerieResponse extends BaseResponse{

    private Serie serie;

    /*** CONSTRUCTORES ***/
    public SerieResponse(Serie serie){
        this.error = null;
        this.errorGeneral = null;
        this.serie = serie;
    }

    public SerieResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.serie = null;
    }

    public SerieResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.serie = null;
    }

    /******** SET AND GET*********/
    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
    }
}
