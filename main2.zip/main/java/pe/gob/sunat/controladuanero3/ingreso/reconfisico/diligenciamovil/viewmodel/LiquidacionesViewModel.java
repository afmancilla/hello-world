package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.LiquidacionesResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.AsignacionRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;

public class LiquidacionesViewModel extends AndroidViewModel {

    public static final String TAG = LiquidacionesViewModel.class.getSimpleName();

    private MediatorLiveData<LiquidacionesResponse> lcsResponse;

    private DamRepository damRepository;

    @Inject
    public LiquidacionesViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository
    ) {
        super(application);
        this.damRepository = damRepository;
        lcsResponse = new MediatorLiveData<>();
    }

    public LiveData<LiquidacionesResponse> getListaLCs (String token, String idDam){
        if(lcsResponse.getValue() == null){
            lcsResponse.addSource(damRepository.getListaLCs(token, idDam), response -> lcsResponse.setValue(response));
        }
        return lcsResponse;
    }
}
