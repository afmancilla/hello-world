package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class AdvertenciaResponse extends BaseResponse {

    private List<Advertencia> advertencias;

    public AdvertenciaResponse(List<Advertencia> advertencias) {
        this.error = null;
        this.errorGeneral = null;
        this.advertencias = advertencias;
    }

    public AdvertenciaResponse(ErrorGeneral errorGeneral) {
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.advertencias = null;
    }

    public AdvertenciaResponse(Throwable error) {
        this.error = error;
        this.errorGeneral = null;
        this.advertencias = null;
    }

    public List<Advertencia> getAdvertencias() {
        return advertencias;
    }

    public void setAdvertencias(List<Advertencia> advertencias) {
        this.advertencias = advertencias;
    }
}
