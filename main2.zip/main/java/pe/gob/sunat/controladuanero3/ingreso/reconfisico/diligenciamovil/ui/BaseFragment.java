package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui;


import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.util.Log;
import android.view.View;

import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;


public class BaseFragment extends Fragment {

    private static final String TAG = BaseFragment.class.getSimpleName();

    @BindView(R.id.text_view_subtitulo)
    TextView subTitulo;

    Unbinder unbinder;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        unbinder = ButterKnife.bind(this, view);

    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if(unbinder!=null){
            unbinder.unbind();
        }
    }

    protected void setSubTitulo(String titulo){
        subTitulo.setText(titulo);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if(unbinder!=null){
            unbinder.unbind();
        }
    }
}
