package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "links",
        "content",
        "page"
})
public class Series {

    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("content")
    private List<Serie> series;
    @JsonProperty("page")
    private Page page;

    private List<Serie> seriesFiltradas = new ArrayList<>();

    /*** SET AND GET ***/
    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public List<Serie> getSeries() {
        return series;
    }

    public void setSeries(List<Serie> series) {
        this.series = series;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }


    public List<Serie> getSeriesFiltradas() {
        return seriesFiltradas;
    }

    public void setSeriesFiltradas(List<Serie> seriesFiltradas) {
        this.seriesFiltradas = seriesFiltradas;
    }
}
