package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;


import java.util.List;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.LiquidacionCobranza;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;

public class AdapterLCList extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<LiquidacionCobranza> lcs;
    private Context ctx;
    private int animation_type = 0;

    public AdapterLCList(Context ctx, List<LiquidacionCobranza> lcs, int animation_type) {
        this.lcs = lcs;
        this.ctx = ctx;
        this.animation_type = animation_type;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lcs_list,parent,false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if(holder instanceof OriginalViewHolder){
            final OriginalViewHolder view = (OriginalViewHolder)holder;
            final LiquidacionCobranza lc = lcs.get(position);

            view.nroLC.setText(lc.getNroLC());
            view.cancelacion.setText(lc.getCancelacion());
            view.fechaCancelacion.setText(lc.getFechaCancelacion());
            view.fechaLiquidacion.setText(lc.getFechaLiquidacion());
            view.monto.setText(lc.getMonto());
            view.sustento.setText(lc.getSustento());
            view.tipoLC.setText(lc.getTipoLC());

            view.bt_expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean show = toggleLayoutExpand(!lc.isExpanded(),v,view.lyt_expand);
                    lcs.get(position).setExpanded(show);
                }
            });

            if(lc.isExpanded()){
                view.lyt_expand.setVisibility(View.VISIBLE);
            } else {
                view.lyt_expand.setVisibility(View.GONE);
            }
            Tools.toggleArrow(lc.isExpanded(), view.bt_expand, false);
            setAnimation(holder.itemView, position);
        }
    }

    public void addItems(List<LiquidacionCobranza> lcs){
        this.lcs = lcs;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return lcs.size();
    }

    private boolean toggleLayoutExpand(boolean show, View view, View lyt_expand) {
        Tools.toggleArrow(show, view);
        if (show) {
            ViewAnimation.expand(lyt_expand);
        } else {
            ViewAnimation.collapse(lyt_expand);
        }
        return show;
    }


    private class OriginalViewHolder extends RecyclerView.ViewHolder {

        public TextView cancelacion,fechaCancelacion,fechaLiquidacion,
                monto,nroLC,sustento,tipoLC;
        public ImageButton bt_expand;
        public View lyt_expand;
        public View lyt_parent;

        public OriginalViewHolder(View v) {
            super(v);

            nroLC = (TextView) v.findViewById(R.id.text_view_nro_lc);
            cancelacion = v.findViewById(R.id.text_view_cancelacion);
            fechaCancelacion = v.findViewById(R.id.text_view_fecha_cancelacion);
            fechaLiquidacion = v.findViewById(R.id.text_view_fecha_cancelacion);
            monto = v.findViewById(R.id.text_view_monto_lc);
            sustento = v.findViewById(R.id.text_view_sustento);
            tipoLC = v.findViewById(R.id.text_view_tipo_lc);

            bt_expand = (ImageButton) v.findViewById(R.id.bt_expand_lcs);
            lyt_expand = (View) v.findViewById(R.id.lyt_expand_lcs);
            lyt_parent = (View) v.findViewById(R.id.lyt_parent_lcs);
        }
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}
