package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia;


import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.EditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import timber.log.Timber;

import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

public class DiligenciaFragment extends BaseFragment implements Injectable {

    public static final String TAG = DiligenciaFragment.class.getSimpleName();

    @BindView(R.id.edit_text_detalle_diligencia)
    EditText detalleDiligencia;
    @BindView(R.id.edit_text_bultos_reconocidos)
    EditText bultosReconocidos;
    @BindView(R.id.edit_text_fecha_reconocimiento)
    EditText fechaReconocimiento;
    @BindView(R.id.grabar)
    FloatingActionButton grabar;

    private View view;
    private OnFragmentIterationListener listener;

    public interface OnFragmentIterationListener {
        void grabarDiligencia(Bundle bundle);
    }


    public DiligenciaFragment() {
    }

    public static DiligenciaFragment newInstance(Bundle params) {
        DiligenciaFragment df = new DiligenciaFragment();
        df.setArguments(params);
        return df;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_diligencia, container, false);

        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));

        fechaReconocimiento.setOnClickListener((View v) -> dialogDatePickerLight());

        grabar.setOnClickListener(view -> {

            if (listener != null && validarPantalla()) {

                try {
                    Date initDate = new SimpleDateFormat("dd/MM/yyyy").parse(fechaReconocimiento.getText().toString());

                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                    String parsedDate = formatter.format(initDate);

                    params.putString(Constantes.ARG_FEC_RECONFISICO,parsedDate);
                    params.putString(Constantes.ARG_DES_RESULTADO,detalleDiligencia.getText().toString());
                    params.putString(Constantes.ARG_CNT_BULTOSRECON,bultosReconocidos.getText().toString());
                    listener.grabarDiligencia(params);
                } catch (ParseException e) {
                    Timber.e(e);
                    ((BaseActivity)getActivity()).showErrorMessage(e.getMessage());
                }

            }
        });

        return view;
    }

    private boolean validarPantalla()  {
        boolean todoOk = false;

        if(detalleDiligencia.getText().length() > 5
                && bultosReconocidos.getText().length() > 0
                && fechaReconocimiento.getText().length() > 0 ) {

            try {
                Date initDate = new SimpleDateFormat("dd/MM/yyyy").parse(fechaReconocimiento.getText().toString());
                todoOk = true;
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return todoOk;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }


    private void dialogDatePickerLight() {
        Calendar cur_calender = Calendar.getInstance();

        DatePickerDialog datePicker = DatePickerDialog.newInstance(
                (view, year, monthOfYear, dayOfMonth) -> {
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, monthOfYear);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    long date = calendar.getTimeInMillis();

                    fechaReconocimiento.setText(Tools.getFormattedDateSimple(date));
                },
                cur_calender.get(Calendar.YEAR),
                cur_calender.get(Calendar.MONTH),
                cur_calender.get(Calendar.DAY_OF_MONTH)
        );
        datePicker.setThemeDark(false);
        datePicker.setAccentColor(getResources().getColor(R.color.colorPrimary));
        datePicker.setMinDate(cur_calender);
        datePicker.show(getActivity().getFragmentManager(),"Fecha Reconocimiento Físico");
    }

}
