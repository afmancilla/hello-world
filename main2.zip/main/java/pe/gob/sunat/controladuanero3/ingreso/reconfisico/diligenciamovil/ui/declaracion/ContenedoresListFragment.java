package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Contenedor;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.adapter.AdapterContenedoresList;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;


public class ContenedoresListFragment extends BaseFragment implements Injectable {

    public static final String TAG = ContenedoresListFragment.class.getSimpleName();

    @BindView(R.id.recycler_view_contenedores)
    RecyclerView recyclerView;

    private View view;
    private AdapterContenedoresList mAdapter;

    public ContenedoresListFragment() {
    }

    public static ContenedoresListFragment newInstance(Bundle params) {
        ContenedoresListFragment fragment = new ContenedoresListFragment();
        fragment.setArguments(params);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_contenedores_list, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {
        recyclerView = getView().findViewById(R.id.recycler_view_contenedores);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));
        List<Contenedor> contenedores = (ArrayList) params.getSerializable(Constantes.ARG_LIST_CONTENEDORES);

        mAdapter = new AdapterContenedoresList(this.getContext(), contenedores, ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        if (contenedores.size() == 0) {
            ((BaseActivity)getActivity()).showNoFound();
        }
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
    }
}
