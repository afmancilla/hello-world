package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.component;

import android.app.Application;

import javax.inject.Singleton;

import dagger.BindsInstance;
import dagger.Component;
import dagger.android.AndroidInjectionModule;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.DiligenciaApp;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module.AppModule;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module.ActivityModule;

@Singleton
@Component(modules = {
        AndroidInjectionModule.class,
        AppModule.class,
        ActivityModule.class})
public interface AppComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        Builder application(Application application);
        AppComponent build();

    }

    void inject(DiligenciaApp diligenciaApp);
}
