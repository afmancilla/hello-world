package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.RiesgoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;

public class RiesgoViewModel extends AndroidViewModel {

    public static final String TAG = RiesgoViewModel.class.getSimpleName();

    private MediatorLiveData<RiesgoResponse> riesResponse;

    private DamRepository damRepository;

    @Inject
    public RiesgoViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository
    ) {
        super(application);
        this.damRepository = damRepository;
        riesResponse = new MediatorLiveData<>();
    }

    public LiveData<RiesgoResponse> getRiesgos(String token, String idDam) {
        if(riesResponse.getValue()==null
                || !idDam.equals(riesResponse.getValue().getIdDam())) {
            riesResponse.addSource(damRepository.getRiesgos(token, idDam), riesgoResponse -> riesResponse.setValue(riesgoResponse));
        }
        return riesResponse;
    }
}