package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;


import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DeclaracionResponse;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;


public class DeclaracionViewModel extends AndroidViewModel {

    public static final String TAG = DeclaracionViewModel.class.getSimpleName();

    private MediatorLiveData<DeclaracionResponse> damResponse;

    private DamRepository damRepository;

    @Inject
    public DeclaracionViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository) {

        super(application);
        this.damRepository = damRepository;
        damResponse = new MediatorLiveData<>();
    }

    public LiveData<DeclaracionResponse> getDam(String token, String idDam) {

        if(damResponse.getValue()==null
                || damResponse.getValue().getDam()==null
                ||(!idDam.equals(damResponse.getValue().getDam().getIdDam())) ) {

            damResponse.addSource(damRepository.getDam(token, idDam), declaracionResponse -> damResponse.setValue(declaracionResponse));
        }
        return damResponse;
    }

}
