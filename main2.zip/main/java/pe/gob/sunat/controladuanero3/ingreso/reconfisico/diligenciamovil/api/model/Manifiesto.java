package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * Manifiesto
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "aduanaManifiesto",
        "annManifiesto",
        "numManifiesto"
})
public class Manifiesto {


    @JsonProperty("aduanaManifiesto")
    private Catalogo aduanaManifiesto;

    @JsonProperty("annManifiesto")
    private String annManifiesto;

    @JsonProperty("numManifiesto")
    private String numManifiesto;

    public Catalogo getAduanaManifiesto() {
        return aduanaManifiesto;
    }

    public void setAduanaManifiesto(Catalogo aduanaManifiesto) {
        this.aduanaManifiesto = aduanaManifiesto;
    }

    public String getAnnManifiesto() {
        return annManifiesto;
    }

    public void setAnnManifiesto(String annManifiesto) {
        this.annManifiesto = annManifiesto;
    }

    public String getNumManifiesto() {
        return numManifiesto;
    }

    public void setNumManifiesto(String numManifiesto) {
        this.numManifiesto = numManifiesto;
    }
}



