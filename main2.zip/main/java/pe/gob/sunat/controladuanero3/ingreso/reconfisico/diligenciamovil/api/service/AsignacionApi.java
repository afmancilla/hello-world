package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service;



import okhttp3.ResponseBody;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;

import retrofit2.Call;
import retrofit2.http.*;


public interface AsignacionApi {
  
  /**
   * Retorna listado de los documentos asignados al funcionario aduanero
   * @param codFuncionario codigo de registro del funcionario. (required)
   * @param tipo tipo de documentos 01 asignados para diligencia movil (required)
   * @param page el numero de página (optional)
   * @param perPage el numero de registros que nos devuelve cada página (optional)
   *
   * @return Call&lt;List&lt;DocumentosAsignados&gt;&gt;
   */


  @GET("/v1/controladuanero/funcionariosaduaneros/{codFuncionario}/documentosasignados/{tipo}")
  Call<DocumentosAsignados> buscarDocumentosAsignadosPorFuncionario(
          @Header("Authorization") String authHeader,
          @Path("codFuncionario") String codFuncionario,
          @Path("tipo") String tipo
  );

  
  /**
   * Retorna el funcionario aduanero por su codigo de funcionario
   * @param codFuncionario codigo de registro del funcionario aduanero (required)
   *
   * @return Call&lt;FuncionarioAduanero&gt;
   */

  @GET("/v1/controladuanero/funcionariosaduaneros/{codFuncionario}/fotos")
  Call<ResponseBody> buscarFotoFuncionarioPorCodigo(
          @Header("Authorization") String authHeader,
          @Path("codFuncionario") String codFuncionario
  );

  
}

