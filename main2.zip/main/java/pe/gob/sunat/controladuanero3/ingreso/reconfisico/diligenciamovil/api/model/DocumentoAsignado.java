
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "desMotivoAsig",
        "numCorreDoc",
        "fecAsignacion",
        "idDam",
        "fecNumeracion",
        "esOEA",
        "tieneGarantia160",
        "cantTotSeries",
        "links"
})
public class DocumentoAsignado extends BaseModel{

    @JsonProperty("desMotivoAsig")
    private String desMotivoAsig;
    @JsonProperty("numCorreDoc")
    private String numCorreDoc;
    @JsonProperty("fecAsignacion")
    private String fecAsignacion;
    @JsonProperty("idDam")
    private String idDam;
    @JsonProperty("fecNumeracion")
    private String fecNumeracion;
    @JsonProperty("esOEA")
    private Boolean esOEA;
    @JsonProperty("tieneGarantia160")
    private Boolean tieneGarantia160;
    @JsonProperty("cantTotSeries")
    private Integer cantTotSeries;
    @JsonProperty("links")
    private List<Link> links;

    /*** SET AND GET ***/

    public String getDesMotivoAsig() {
        return desMotivoAsig;
    }

    public void setDesMotivoAsig(String desMotivoAsig) {
        this.desMotivoAsig = desMotivoAsig;
    }

    public String getNumCorreDoc() {
        return numCorreDoc;
    }

    public void setNumCorreDoc(String numCorreDoc) {
        this.numCorreDoc = numCorreDoc;
    }

    public String getFecAsignacion() {
        return fecAsignacion;
    }

    public void setFecAsignacion(String fecAsignacion) {
        this.fecAsignacion = fecAsignacion;
    }

    public String getIdDam() {
        return idDam;
    }

    public void setIdDam(String idDam) {
        this.idDam = idDam;
    }

    public String getFecNumeracion() {
        return fecNumeracion;
    }

    public void setFecNumeracion(String fecNumeracion) {
        this.fecNumeracion = fecNumeracion;
    }

    public Boolean getEsOEA() {
        return esOEA;
    }

    public void setEsOEA(Boolean esOEA) {
        this.esOEA = esOEA;
    }

    public Boolean getTieneGarantia160() {
        return tieneGarantia160;
    }

    public void setTieneGarantia160(Boolean tieneGarantia160) {
        this.tieneGarantia160 = tieneGarantia160;
    }

    public Integer getCantTotSeries() {
        return cantTotSeries;
    }

    public void setCantTotSeries(Integer cantTotSeries) {
        this.cantTotSeries = cantTotSeries;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }
}