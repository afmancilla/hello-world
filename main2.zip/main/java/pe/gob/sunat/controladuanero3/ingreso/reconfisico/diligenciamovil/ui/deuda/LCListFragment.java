package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;



import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.LiquidacionCobranza;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda.adapter.AdapterLCList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.LiquidacionesViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import timber.log.Timber;

import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_IDDAM;
import static pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes.ARG_TOKEN;


public class LCListFragment extends BaseFragment implements Injectable {

    public static final String TAG = LCListFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_view_lcs)
    RecyclerView recyclerView;

    private View view;
    private AdapterLCList mAdapter;
    private LiquidacionesViewModel viewModel;

    public LCListFragment() {
    }

    public static LCListFragment newInstance(Bundle params) {
        LCListFragment lcf = new LCListFragment();
        lcf.setArguments(params);
        return lcf;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_lcs_list, container, false);

        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterLCList(this.getContext(), new ArrayList<>(),ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(LiquidacionesViewModel.class);

        String token = getArguments().getString(ARG_TOKEN);
        String idDam = getArguments().getString(ARG_IDDAM);

        viewModel.getListaLCs(token,idDam).observe(this,response -> {

            List<LiquidacionCobranza> lcs = response.getLcs();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if(lcs!=null){
                ((BaseActivity)getActivity()).hideMessage();
                mAdapter.addItems(lcs);
            }else if(error != null){

            String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

            if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                Timber.w(errorMsg);
                ((BaseActivity)getActivity()).showTokenDialog();
            }else if (Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                Timber.i(errorMsg);
                ((BaseActivity)getActivity()).showNoFound();
            }else {
                Timber.e(errorMsg);
                ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
            }
        }else if (throwable != null) {
            Timber.e(throwable.getMessage());
            ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
        }
        });
    }



    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
    }
}
