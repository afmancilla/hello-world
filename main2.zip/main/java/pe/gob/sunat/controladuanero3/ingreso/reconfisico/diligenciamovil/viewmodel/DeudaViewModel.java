package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;


import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DeudaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;

public class DeudaViewModel extends AndroidViewModel {

    public static final String TAG = DeudaViewModel.class.getSimpleName();

    private MediatorLiveData<DeudaResponse> deudaResponse;

    private DamRepository damRepository;

    @Inject
    public DeudaViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository
    ) {
        super(application);

        this.damRepository = damRepository;
        deudaResponse = new MediatorLiveData<>();
    }


    public LiveData<DeudaResponse> getDeudaTributaria(String token, String idDam) {

        if(deudaResponse.getValue()==null
                || !idDam.equals(deudaResponse.getValue().getIdDam())) {

            deudaResponse.addSource(damRepository.getDeudaTributaria(token, idDam), response -> deudaResponse.setValue(response));
        }
        return deudaResponse;
    }
}
